/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "f5dc1367a6a24531c331f751d6283d3e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e739b490721355de469bf50e569c0d00"
  }, {
    "url": "pwa-192x192.png",
    "revision": "7043ae3818f857f83b53b3ffdfd85b0b"
  }, {
    "url": "index.html",
    "revision": "5654e4f0867f727dec4535e60b98f82d"
  }, {
    "url": "icon.svg",
    "revision": "3222390cfb962cedf3ad0dc4cfc48e88"
  }, {
    "url": "favicon.ico",
    "revision": "c2302f163362d230e3bfa05d783f0948"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "f35f415fa80c2645e37d5217641ce16e"
  }, {
    "url": "Nexbill_Solar_Pro_Portable.html",
    "revision": "181844adaf603a649369c5b52acfce00"
  }, {
    "url": "Nexbill_Solar_Pro_Offline.html",
    "revision": "181844adaf603a649369c5b52acfce00"
  }, {
    "url": "assets/purify.es-BZxk_wWO.js",
    "revision": null
  }, {
    "url": "assets/index.es-x6hxSs64.js",
    "revision": null
  }, {
    "url": "assets/index-CRkRAdTp.css",
    "revision": null
  }, {
    "url": "assets/index-C099xDnV.js",
    "revision": null
  }, {
    "url": "assets/aistudio/image_e8643c13.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_cbd2b3b4.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_b27d2384.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_7fdf4eff.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_6071688c.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_1c7d2c9e.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_0518f948.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "f35f415fa80c2645e37d5217641ce16e"
  }, {
    "url": "favicon.ico",
    "revision": "c2302f163362d230e3bfa05d783f0948"
  }, {
    "url": "icon.svg",
    "revision": "3222390cfb962cedf3ad0dc4cfc48e88"
  }, {
    "url": "pwa-192x192.png",
    "revision": "7043ae3818f857f83b53b3ffdfd85b0b"
  }, {
    "url": "pwa-512x512.png",
    "revision": "e739b490721355de469bf50e569c0d00"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "f5dc1367a6a24531c331f751d6283d3e"
  }, {
    "url": "manifest.webmanifest",
    "revision": "8bb508bf6e1f60eba5afdcf450313c55"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
