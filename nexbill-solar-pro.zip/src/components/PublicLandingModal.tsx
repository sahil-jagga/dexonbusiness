import React, { useState } from 'react';
import {
  Sun,
  ShieldCheck,
  Zap,
  FileText,
  Calculator,
  Check,
  PhoneCall,
  Key,
  Award,
  ChevronRight,
  TrendingUp,
  Percent
} from 'lucide-react';

interface PublicLandingModalProps {
  isOpen: boolean;
  onUnlockWithKey: (key: string) => Promise<{ success: boolean; message?: string }>;
  onTryTrial: () => void;
  onOpenAdmin: () => void;
}

export const PublicLandingModal: React.FC<PublicLandingModalProps> = ({
  isOpen,
  onUnlockWithKey,
  onTryTrial,
  onOpenAdmin,
}) => {
  const [keyInput, setKeyInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [verifying, setVerifying] = useState(false);

  if (!isOpen) return null;

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyInput.trim()) {
      setErrorMsg('Please enter a license key.');
      return;
    }
    setVerifying(true);
    setErrorMsg('');
    const res = await onUnlockWithKey(keyInput.trim());
    setVerifying(false);
    if (!res.success) {
      setErrorMsg(res.message || 'Invalid or revoked license key.');
    }
  };

  const handleWhatsAppBuy = (plan: string, price: string) => {
    const text = encodeURIComponent(
      `Hi Sahil, I want to purchase Nexbill Solar Pro (${plan} - ${price}). Please share payment details & activation key.`
    );
    window.open(`https://wa.me/919429842000?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 p-3 sm:p-6 backdrop-blur-md overflow-y-auto">
      <div className="my-auto flex w-full max-w-4xl flex-col rounded-3xl border border-amber-500/30 bg-slate-900 shadow-2xl overflow-hidden text-slate-100">
        {/* Hero Banner */}
        <div className="relative bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 p-6 sm:p-8 border-b border-slate-800">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30">
                <Sun className="h-7 w-7 animate-spin-slow" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                    NEXBILL SOLAR <span className="text-amber-400">PRO</span>
                  </h1>
                  <span className="rounded-full bg-amber-500/20 px-2.5 py-0.5 text-[10px] font-bold text-amber-400 border border-amber-500/30">
                    V2.5 SaaS
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Dedicated Invoicing, 70:30 GST Optimization & WCC Tool for Solar EPC Vendors
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onOpenAdmin}
                className="rounded-lg border border-slate-700 bg-slate-800/80 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-700 hover:text-white"
              >
                Owner / Admin Login
              </button>
            </div>
          </div>

          {/* Quick License Input in Hero */}
          <div className="mt-6 rounded-2xl border border-amber-500/40 bg-slate-950/80 p-4 sm:p-5 shadow-xl">
            <form onSubmit={handleUnlock} className="flex flex-col sm:flex-row gap-3 items-center">
              <div className="relative flex-1 w-full">
                <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-amber-400" />
                <input
                  type="text"
                  placeholder="ENTER LICENSE KEY (e.g. TRIAL-NEXBILL-2026)"
                  value={keyInput}
                  onChange={(e) => setKeyInput(e.target.value.toUpperCase())}
                  className="w-full rounded-xl border border-slate-700 bg-slate-900 py-3 pl-10 pr-4 text-sm font-bold tracking-wider text-amber-400 placeholder:text-slate-500 placeholder:tracking-normal focus:border-amber-400 focus:outline-none"
                />
              </div>
              <button
                type="submit"
                disabled={verifying}
                className="w-full sm:w-auto shrink-0 rounded-xl bg-amber-500 px-6 py-3 text-sm font-extrabold text-slate-950 shadow-lg shadow-amber-500/20 transition hover:bg-amber-400 disabled:opacity-50"
              >
                {verifying ? 'Verifying Key...' : 'Unlock Tool 🔓'}
              </button>
              <button
                type="button"
                onClick={onTryTrial}
                className="w-full sm:w-auto shrink-0 rounded-xl border border-emerald-500/50 bg-emerald-950/40 px-4 py-3 text-xs font-bold text-emerald-300 hover:bg-emerald-900/40"
              >
                Test Free Trial (5 Bills)
              </button>
            </form>

            {errorMsg && (
              <div className="mt-2 text-xs font-semibold text-rose-400 text-center sm:text-left">
                {errorMsg}
              </div>
            )}
          </div>
        </div>

        {/* Feature Highlights Grid */}
        <div className="p-6 sm:p-8">
          <div className="text-center max-w-xl mx-auto mb-6">
            <h2 className="text-base sm:text-lg font-bold text-white">
              Why Indian Solar Installers Choose Nexbill over Generic Billing Apps
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              Built specifically for PM Surya Ghar: Muft Bijli Yojana & State DISCOM compliance
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4 hover:border-amber-500/30 transition">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/10 text-amber-400 mb-3">
                <Percent className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-white">70:30 GST Auto Optimizer</h3>
              <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                Automatically calculates 5% GST (Solar panels & Inverter) vs 18% GST (BOS, Structure, Installation) to ensure DISCOM invoice approval.
              </p>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4 hover:border-amber-500/30 transition">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 mb-3">
                <FileText className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-white">4 Essential Solar Docs in 1 Click</h3>
              <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                Generate Tax Invoice (Original/Duplicate), PM Surya Ghar WCC Certificate, Customer Quotation with ROI, and Bank Loan Estimate.
              </p>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-slate-950/50 p-4 hover:border-amber-500/30 transition">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-500/10 text-blue-400 mb-3">
                <Calculator className="h-5 w-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Reverse Target Pricing</h3>
              <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                Give a target price (e.g. ₹1,80,000 for 3kW) and your cost rates; the tool auto-computes exact item rates and tax margins instantly.
              </p>
            </div>
          </div>

          {/* Pricing Plans for Sale */}
          <div className="mt-8 border-t border-slate-800 pt-6">
            <div className="text-center mb-6">
              <h3 className="text-base font-bold text-white">License Plans for Solar Contractors</h3>
              <p className="text-xs text-slate-400">One-time transparent pricing. No monthly recurring headache.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 max-w-2xl mx-auto">
              {/* Pro Plan */}
              <div className="relative rounded-2xl border-2 border-amber-500 bg-slate-950 p-5 shadow-xl">
                <div className="absolute -top-3 right-4 rounded-full bg-amber-500 px-3 py-0.5 text-[10px] font-black uppercase text-slate-950 tracking-wider">
                  Most Popular
                </div>
                <div className="text-sm font-bold text-amber-400">⭐ Pro License</div>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-3xl font-extrabold text-white">₹999</span>
                  <span className="text-xs text-slate-400">/ 1 Year</span>
                </div>
                <p className="mt-1 text-xs text-slate-400">Perfect for individual solar EPC vendors</p>

                <ul className="mt-4 space-y-2 text-xs text-slate-300">
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    <b>Unlimited Invoices & Quotations</b>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    All 3 Premium Invoice Templates
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    PM Surya Ghar WCC & Bank Estimates
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    Custom Firm Logo, GST & Bank Details
                  </li>
                </ul>

                <button
                  onClick={() => handleWhatsAppBuy('Pro Plan', '₹999/yr')}
                  className="mt-5 w-full rounded-xl bg-amber-500 py-2.5 text-xs font-extrabold text-slate-950 hover:bg-amber-400 flex items-center justify-center gap-2"
                >
                  <PhoneCall className="h-4 w-4" /> Buy Pro Key via WhatsApp (94298-42000)
                </button>
              </div>

              {/* Business Plan */}
              <div className="rounded-2xl border border-slate-700 bg-slate-950/60 p-5 hover:border-purple-500/50 transition">
                <div className="text-sm font-bold text-purple-400">🚀 Business License</div>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-3xl font-extrabold text-white">₹1,999</span>
                  <span className="text-xs text-slate-400">/ 1 Year</span>
                </div>
                <p className="mt-1 text-xs text-slate-400">For multi-firm EPC companies & distributors</p>

                <ul className="mt-4 space-y-2 text-xs text-slate-300">
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-purple-400" />
                    <b>Everything in Pro + Multi-Firm Switcher</b>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-purple-400" />
                    Customer Database CRM & History
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-purple-400" />
                    Monthly GST Return Export (GSTR-1 format)
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-purple-400" />
                    Priority Support & Custom Template Branding
                  </li>
                </ul>

                <button
                  onClick={() => handleWhatsAppBuy('Business Plan', '₹1,999/yr')}
                  className="mt-5 w-full rounded-xl bg-purple-600 py-2.5 text-xs font-extrabold text-white hover:bg-purple-500 flex items-center justify-center gap-2"
                >
                  <PhoneCall className="h-4 w-4" /> Buy Business Key via WhatsApp
                </button>
              </div>
            </div>

            {/* Direct Contact Footer */}
            <div className="mt-6 text-center text-xs text-slate-400">
              Direct Contact: <b className="text-white">Jagga Enterprises</b> — Call / WhatsApp: <a href="tel:9429842000" className="text-amber-400 font-bold hover:underline">94298-42000</a> | <a href="tel:9428342000" className="text-amber-400 font-bold hover:underline">94283-42000</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
