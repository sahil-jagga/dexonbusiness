import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  KeyRound,
  Trash2,
  Ban,
  CheckCircle2,
  Copy,
  Plus,
  Share2,
  X,
  RefreshCw,
  Download,
  AlertTriangle,
  UserCheck
} from 'lucide-react';
import { licenseService } from '../services/licenseService';

interface AdminPortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLicenseChanged?: () => void;
}

export const AdminPortalModal: React.FC<AdminPortalModalProps> = ({
  isOpen,
  onClose,
  onLicenseChanged,
}) => {
  const [pin, setPin] = useState('sahil2026');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  // Licenses list & stats
  const [licenses, setLicenses] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, active: 0, revoked: 0, totalInvoices: 0 });
  const [filter, setFilter] = useState<'all' | 'active' | 'revoked'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // New License Form
  const [showAddForm, setShowAddForm] = useState(false);
  const [newClientName, setNewClientName] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');
  const [newPlan, setNewPlan] = useState<'Trial' | 'Pro' | 'Business'>('Pro');
  const [durationMonths, setDurationMonths] = useState(12);
  const [newCustomKey, setNewCustomKey] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && isAuthenticated) {
      loadLicenses();
    }
  }, [isOpen, isAuthenticated]);

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    setErrorMsg('');
    try {
      const isValid = await licenseService.verifyAdminPin(pin);
      if (isValid) {
        setIsAuthenticated(true);
        await loadLicenses();
      } else {
        setErrorMsg('❌ Invalid Admin PIN. Default is: sahil2026 or 94298');
      }
    } catch {
      setErrorMsg('Failed to authenticate admin');
    } finally {
      setLoading(false);
    }
  };

  const loadLicenses = async () => {
    try {
      setLoading(true);
      const data = await licenseService.fetchAllLicenses(pin);
      setLicenses(data.licenses || []);
      setStats(data.stats || { total: 0, active: 0, revoked: 0, totalInvoices: 0 });
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to load licenses');
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = async (key: string) => {
    try {
      await licenseService.toggleLicense(pin, key);
      await loadLicenses();
      if (onLicenseChanged) onLicenseChanged();
    } catch (err: any) {
      alert('Error updating license: ' + err.message);
    }
  };

  const handleDelete = async (key: string) => {
    if (!confirm(`Are you sure you want to permanently DELETE key: ${key}? The user will be locked out.`)) {
      return;
    }
    try {
      await licenseService.deleteLicense(pin, key);
      await loadLicenses();
      if (onLicenseChanged) onLicenseChanged();
    } catch (err: any) {
      alert('Error deleting license: ' + err.message);
    }
  };

  const handleCreateLicense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientName.trim()) {
      alert('Please enter client/vendor name');
      return;
    }

    const expiryDate = new Date();
    expiryDate.setMonth(expiryDate.getMonth() + Number(durationMonths));
    const expiryStr = expiryDate.toISOString().split('T')[0];

    try {
      setLoading(true);
      await licenseService.createLicense(pin, {
        clientName: newClientName,
        clientPhone: newClientPhone,
        plan: newPlan,
        expiry: expiryStr,
        invoiceLimit: newPlan === 'Trial' ? 5 : 99999,
        customKey: newCustomKey.trim() || undefined,
        notes: newNotes,
      });

      // Reset form
      setNewClientName('');
      setNewClientPhone('');
      setNewCustomKey('');
      setNewNotes('');
      setShowAddForm(false);
      await loadLicenses();
      if (onLicenseChanged) onLicenseChanged();
    } catch (err: any) {
      alert('Error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleWhatsAppSend = (item: any) => {
    const text = encodeURIComponent(
      `*⚡ Nexbill Solar Pro — License Key Details*\n\n` +
      `Hello *${item.clientName}*,\n` +
      `Here is your activation license key for Nexbill Solar Pro:\n\n` +
      `🔑 *License Key:* \`${item.key}\`\n` +
      `📦 *Plan:* ${item.plan}\n` +
      `📅 *Validity Expire:* ${item.expiry}\n` +
      `📄 *Invoice Limit:* ${item.invoiceLimit > 100 ? 'Unlimited' : item.invoiceLimit + '/month'}\n\n` +
      `🌐 *Access Tool:* ${window.location.origin}\n` +
      `Instructions: Open the website link, click 'Enter License Key', paste your key and click 'Unlock'.\n\n` +
      `Support: 94298-42000 | Jagga Enterprises`
    );
    const phone = item.clientPhone ? item.clientPhone.replace(/[^0-9]/g, '') : '';
    const url = phone ? `https://wa.me/91${phone}?text=${text}` : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 backdrop-blur-sm">
      <div className="flex h-[90vh] w-full max-w-5xl flex-col rounded-2xl border border-amber-500/30 bg-slate-900 shadow-2xl text-slate-100">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400">
              <ShieldAlert className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Nexbill Admin License Manager
                <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-semibold text-emerald-400">
                  Zero-Cost Cloud Sync
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Track, generate, block, or delete client licenses in real-time.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        {!isAuthenticated ? (
          <div className="flex flex-1 items-center justify-center p-6">
            <form
              onSubmit={handleLogin}
              className="w-full max-w-sm rounded-xl border border-slate-800 bg-slate-950/70 p-6 text-center shadow-lg"
            >
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/10 text-amber-400">
                <KeyRound className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-white">Owner / Admin Security PIN</h3>
              <p className="mt-1 text-xs text-slate-400">
                Enter your secret PIN to access license controls & tracking.
              </p>

              <div className="mt-4">
                <input
                  type="password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="Enter PIN"
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2.5 text-center text-lg font-bold tracking-widest text-amber-400 focus:border-amber-400 focus:outline-none"
                  autoFocus
                />
              </div>

              {errorMsg && (
                <div className="mt-2 text-xs font-medium text-rose-400">{errorMsg}</div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="mt-4 w-full rounded-lg bg-amber-500 py-2.5 text-sm font-bold text-slate-950 transition hover:bg-amber-400 disabled:opacity-50"
              >
                {loading ? 'Verifying...' : 'Access License Panel'}
              </button>

              <div className="mt-3 text-[11px] text-slate-500">
                Default Master PIN: <span className="font-mono text-slate-400">sahil2026</span>
              </div>
            </form>
          </div>
        ) : (
          <div className="flex flex-1 flex-col overflow-hidden p-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3">
                <div className="text-[11px] font-medium text-slate-400">Total Issued Keys</div>
                <div className="mt-1 text-xl font-extrabold text-white">{stats.total}</div>
              </div>
              <div className="rounded-xl border border-emerald-900/40 bg-emerald-950/20 p-3">
                <div className="text-[11px] font-medium text-emerald-400">Active Licenses</div>
                <div className="mt-1 text-xl font-extrabold text-emerald-400">{stats.active}</div>
              </div>
              <div className="rounded-xl border border-rose-900/40 bg-rose-950/20 p-3">
                <div className="text-[11px] font-medium text-rose-400">Revoked / Blocked</div>
                <div className="mt-1 text-xl font-extrabold text-rose-400">{stats.revoked}</div>
              </div>
              <div className="rounded-xl border border-amber-900/40 bg-amber-950/20 p-3">
                <div className="text-[11px] font-medium text-amber-400">Invoices Created</div>
                <div className="mt-1 text-xl font-extrabold text-amber-400">{stats.totalInvoices}</div>
              </div>
            </div>

            {/* Actions Bar */}
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Search by client or key..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
                <div className="flex rounded-lg border border-slate-800 bg-slate-950 p-0.5 text-xs">
                  <button
                    onClick={() => setFilter('all')}
                    className={`rounded px-2.5 py-1 ${
                      filter === 'all' ? 'bg-amber-500 text-slate-950 font-semibold' : 'text-slate-400'
                    }`}
                  >
                    All ({licenses.length})
                  </button>
                  <button
                    onClick={() => setFilter('active')}
                    className={`rounded px-2.5 py-1 ${
                      filter === 'active' ? 'bg-emerald-500 text-slate-950 font-semibold' : 'text-slate-400'
                    }`}
                  >
                    Active
                  </button>
                  <button
                    onClick={() => setFilter('revoked')}
                    className={`rounded px-2.5 py-1 ${
                      filter === 'revoked' ? 'bg-rose-500 text-slate-950 font-semibold' : 'text-slate-400'
                    }`}
                  >
                    Revoked
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={loadLicenses}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
                  title="Refresh"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
                <a
                  href={`/api/admin/export?admin_pin=${pin}`}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-950 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
                  download
                >
                  <Download className="h-3.5 w-3.5" />
                  Backup JSON
                </a>
                <button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-1.5 text-xs font-bold text-slate-950 hover:bg-amber-400"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Issue New Key
                </button>
              </div>
            </div>

            {/* Issue New Key Form Popup */}
            {showAddForm && (
              <form
                onSubmit={handleCreateLicense}
                className="mt-3 rounded-xl border border-amber-500/40 bg-slate-950 p-4 shadow-xl"
              >
                <div className="mb-3 flex items-center justify-between border-b border-slate-800 pb-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <KeyRound className="h-4 w-4" /> Issue New Client License Key
                  </h4>
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="text-slate-400 hover:text-white"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-4">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Client / Vendor Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Apex Solar Energy"
                      value={newClientName}
                      onChange={(e) => setNewClientName(e.target.value)}
                      className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">WhatsApp / Phone</label>
                    <input
                      type="text"
                      placeholder="e.g. 98290-12345"
                      value={newClientPhone}
                      onChange={(e) => setNewClientPhone(e.target.value)}
                      className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">License Plan</label>
                    <select
                      value={newPlan}
                      onChange={(e: any) => setNewPlan(e.target.value)}
                      className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                    >
                      <option value="Pro">⭐ Pro (Unlimited Bills, ₹999/yr)</option>
                      <option value="Business">🚀 Business (Multi-Firm, ₹1,999/yr)</option>
                      <option value="Trial">🆓 Free Trial (5 Bills/Month)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Validity Duration</label>
                    <select
                      value={durationMonths}
                      onChange={(e) => setDurationMonths(Number(e.target.value))}
                      className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                    >
                      <option value={1}>1 Month (Monthly test)</option>
                      <option value={3}>3 Months</option>
                      <option value={6}>6 Months</option>
                      <option value={12}>1 Year (Recommended)</option>
                      <option value={24}>2 Years</option>
                      <option value={60}>5 Years (Lifetime)</option>
                    </select>
                  </div>
                </div>

                <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      Custom License Key (Leave empty to auto-generate)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. NXB-PRO-APEX-2026"
                      value={newCustomKey}
                      onChange={(e) => setNewCustomKey(e.target.value.toUpperCase())}
                      className="w-full font-mono rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-amber-300 focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Notes / Payment Ref</label>
                    <input
                      type="text"
                      placeholder="e.g. Paid Rs 999 via UPI txn #9821"
                      value={newNotes}
                      onChange={(e) => setNewNotes(e.target.value)}
                      className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-xs text-white focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="mt-4 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="rounded border border-slate-700 px-3 py-1 text-xs text-slate-400 hover:bg-slate-800"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="rounded bg-emerald-600 px-4 py-1.5 text-xs font-bold text-white hover:bg-emerald-500"
                  >
                    Generate & Save Key
                  </button>
                </div>
              </form>
            )}

            {/* Licenses Table */}
            <div className="mt-4 flex-1 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950/70">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900 text-slate-400">
                    <th className="py-2.5 px-3">Client / Vendor</th>
                    <th className="py-2.5 px-3">License Key</th>
                    <th className="py-2.5 px-3">Plan</th>
                    <th className="py-2.5 px-3">Expiry</th>
                    <th className="py-2.5 px-3 text-center">Invoices</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3 text-right">Actions (Revoke / Share)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {licenses
                    .filter((l) => {
                      if (filter === 'active') return l.isActive;
                      if (filter === 'revoked') return !l.isActive;
                      return true;
                    })
                    .filter((l) => {
                      if (!searchTerm) return true;
                      const s = searchTerm.toLowerCase();
                      return (
                        l.clientName.toLowerCase().includes(s) ||
                        l.key.toLowerCase().includes(s) ||
                        (l.clientPhone && l.clientPhone.includes(s))
                      );
                    })
                    .map((item) => {
                      const isExpired = new Date(item.expiry + 'T23:59:59') < new Date();
                      return (
                        <tr key={item.key} className="hover:bg-slate-900/50">
                          <td className="py-2.5 px-3">
                            <div className="font-semibold text-white">{item.clientName}</div>
                            {item.clientPhone && (
                              <div className="text-[10px] text-slate-400">{item.clientPhone}</div>
                            )}
                            {item.notes && (
                              <div className="text-[10px] italic text-amber-400/80">{item.notes}</div>
                            )}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-bold text-amber-300">
                            <div className="flex items-center gap-1.5">
                              <span>{item.key}</span>
                              <button
                                onClick={() => handleCopyKey(item.key)}
                                className="text-slate-400 hover:text-white"
                                title="Copy Key"
                              >
                                {copiedKey === item.key ? (
                                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                                ) : (
                                  <Copy className="h-3.5 w-3.5" />
                                )}
                              </button>
                            </div>
                          </td>
                          <td className="py-2.5 px-3">
                            <span
                              className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                item.plan === 'Business'
                                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                                  : item.plan === 'Pro'
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                  : 'bg-slate-700/50 text-slate-300'
                              }`}
                            >
                              {item.plan}
                            </span>
                          </td>
                          <td className="py-2.5 px-3">
                            <div className={isExpired ? 'font-bold text-rose-400' : 'text-slate-300'}>
                              {item.expiry}
                            </div>
                            {isExpired && (
                              <div className="text-[10px] text-rose-400 font-semibold">Expired</div>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-center font-bold text-slate-300">
                            {item.totalInvoicesGenerated || 0}
                            <span className="text-[10px] font-normal text-slate-500">
                              {' '}
                              / {item.invoiceLimit > 100 ? '∞' : item.invoiceLimit}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            {item.isActive ? (
                              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-400">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                                Active
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 rounded-full bg-rose-500/15 px-2 py-0.5 text-[10px] font-bold text-rose-400">
                                <Ban className="h-3 w-3" />
                                Revoked
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* WhatsApp Share */}
                              <button
                                onClick={() => handleWhatsAppSend(item)}
                                className="flex items-center gap-1 rounded bg-emerald-950/40 border border-emerald-700/50 px-2 py-1 text-[11px] font-medium text-emerald-300 hover:bg-emerald-900/60"
                                title="Send key to buyer via WhatsApp"
                              >
                                <Share2 className="h-3 w-3" />
                                WA
                              </button>

                              {/* Revoke / Unrevoke Toggle */}
                              <button
                                onClick={() => handleToggle(item.key)}
                                className={`rounded px-2 py-1 text-[11px] font-medium transition ${
                                  item.isActive
                                    ? 'bg-rose-950/40 border border-rose-700/50 text-rose-300 hover:bg-rose-900/50'
                                    : 'bg-emerald-950/40 border border-emerald-700/50 text-emerald-300 hover:bg-emerald-900/50'
                                }`}
                                title={item.isActive ? 'Block/Revoke this key' : 'Activate this key'}
                              >
                                {item.isActive ? 'Revoke' : 'Activate'}
                              </button>

                              {/* Delete */}
                              <button
                                onClick={() => handleDelete(item.key)}
                                className="rounded p-1 text-slate-500 hover:bg-rose-950 hover:text-rose-400"
                                title="Delete key permanently"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>

              {licenses.length === 0 && (
                <div className="p-8 text-center text-slate-500">No licenses found.</div>
              )}
            </div>

            {/* Zero Cost Guide Tip */}
            <div className="mt-3 flex items-start gap-2 rounded-lg border border-slate-800 bg-slate-950 p-2.5 text-[11px] text-slate-400">
              <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
              <div>
                <span className="font-bold text-amber-300">Aapka Sawal ("Kya bina kharche ke key track or delete kr skta hu?"): </span>
                Haan bilkul! Yeh tool isi cloud server pe chal raha hai bina kisi extra hosting kharche ke. Jab aap kisi client ko key dete hain, toh unka browser har baar isi server se check karta hai. Agar aap yahan se <b className="text-rose-300">'Revoke'</b> ya <b className="text-rose-300">'Delete'</b> kar denge, toh client ka tool turant block ho jayega aur unhe renewal ke liye call karna padega!
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
