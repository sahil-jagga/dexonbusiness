import React from 'react';
import { Sparkles, PhoneCall, Check, X } from 'lucide-react';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEnterKey: () => void;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({ isOpen, onClose, onEnterKey }) => {
  if (!isOpen) return null;

  const handleWhatsAppBuy = (plan: string, price: string) => {
    const text = encodeURIComponent(
      `Hi Sahil, my free trial limit has been reached. I want to buy Nexbill Solar (${plan} - ${price}). Please send payment QR.`
    );
    window.open(`https://wa.me/919429842000?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-2xl border-2 border-amber-500 bg-slate-900 p-6 text-slate-100 shadow-2xl">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400">
              <Sparkles className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Trial Limit Reached 🚀</h2>
              <p className="text-xs text-amber-400 font-semibold">
                Upgrade to Pro for Unlimited Invoices
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="mt-3 text-xs text-slate-300 leading-relaxed">
          Aapki free trial limit (5 bills/month) poori ho chuki hai. Apne solar business ko bina kisi rukawat chalane ke liye Pro ya Business plan lein!
        </p>

        {/* Plans */}
        <div className="mt-4 space-y-3">
          <div
            onClick={() => handleWhatsAppBuy('Pro Plan', '₹999/yr')}
            className="cursor-pointer rounded-xl border border-amber-500/50 bg-slate-950 p-3 hover:border-amber-400 transition"
          >
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold text-amber-400">⭐ Pro Plan</div>
              <div className="text-base font-extrabold text-white">₹999 / year</div>
            </div>
            <div className="mt-1 text-[11px] text-slate-400 space-y-0.5">
              <div className="flex items-center gap-1.5 text-slate-300">
                <Check className="h-3 w-3 text-emerald-400" /> Unlimited Invoices & Quotations
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                <Check className="h-3 w-3 text-emerald-400" /> All 3 Invoice Themes + WCC Certificate
              </div>
            </div>
          </div>

          <div
            onClick={() => handleWhatsAppBuy('Business Plan', '₹1,999/yr')}
            className="cursor-pointer rounded-xl border border-purple-500/50 bg-slate-950 p-3 hover:border-purple-400 transition"
          >
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold text-purple-400">🚀 Business Plan</div>
              <div className="text-base font-extrabold text-white">₹1,999 / year</div>
            </div>
            <div className="mt-1 text-[11px] text-slate-400 space-y-0.5">
              <div className="flex items-center gap-1.5 text-slate-300">
                <Check className="h-3 w-3 text-purple-400" /> Multi-Firm Support & Customer CRM
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                <Check className="h-3 w-3 text-purple-400" /> GSTR-1 Sales Report & Priority Support
              </div>
            </div>
          </div>
        </div>

        {/* Call support */}
        <div className="mt-4 rounded-xl bg-slate-950 p-3 text-center border border-slate-800">
          <div className="text-xs text-slate-400">License activate karane ke liye call ya WhatsApp karein:</div>
          <div className="mt-1 text-sm font-bold text-amber-400 flex items-center justify-center gap-1.5">
            <PhoneCall className="h-4 w-4" /> 94298-42000 / 94283-42000
          </div>
        </div>

        <div className="mt-4 flex gap-2">
          <button
            onClick={() => {
              onClose();
              onEnterKey();
            }}
            className="flex-1 rounded-lg border border-slate-700 bg-slate-800 py-2 text-xs font-bold text-slate-300 hover:bg-slate-700"
          >
            Enter Key
          </button>
          <button
            onClick={() => handleWhatsAppBuy('Pro Plan', '₹999/yr')}
            className="flex-1 rounded-lg bg-amber-500 py-2 text-xs font-extrabold text-slate-950 hover:bg-amber-400 flex items-center justify-center gap-1"
          >
            <PhoneCall className="h-3.5 w-3.5" /> Buy via WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
};
