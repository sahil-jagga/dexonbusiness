import React, { useState } from 'react';
import {
  Calculator,
  Plus,
  Trash2,
  Sparkles,
  Layers,
  ArrowRight,
  Sliders,
  CheckCircle,
  AlertTriangle,
  Info
} from 'lucide-react';
import { InvoiceItem, StockItem } from '../types/solar';
import { formatIntegerINR } from '../services/licenseService';

interface SidebarCalculatorProps {
  items: InvoiceItem[];
  onItemsChange: (items: InvoiceItem[]) => void;
  targetPrice: number;
  onTargetPriceChange: (val: number) => void;
  stockLibrary: StockItem[];
  onAddStockItem: (item: StockItem) => void;
  onDeleteStockItem: (name: string) => void;
  currency: string;
}

export const SidebarCalculator: React.FC<SidebarCalculatorProps> = ({
  items,
  onItemsChange,
  targetPrice,
  onTargetPriceChange,
  stockLibrary,
  onAddStockItem,
  onDeleteStockItem,
  currency,
}) => {
  const [newStockName, setNewStockName] = useState('');
  const [newStockHsn, setNewStockHsn] = useState('');
  const [newStockGst, setNewStockGst] = useState<number>(18);
  const [newStockBuy, setNewStockBuy] = useState<number>(1000);

  // Compute Buying Total (w/GST)
  const totalBuyWithGst = items.reduce((acc, it) => {
    const buyLine = (it.buyRate || 0) * (it.qty || 1);
    return acc + buyLine * (1 + (it.gst || 0) / 100);
  }, 0);

  // Compute Selling Total (w/GST)
  const totalSellWithGst = items.reduce((acc, it) => {
    const sellLine = (it.rate || 0) * (it.qty || 1);
    return acc + sellLine * (1 + (it.gst || 0) / 100);
  }, 0);

  const profit = Math.round(totalSellWithGst - totalBuyWithGst);
  const profitPercent = totalBuyWithGst > 0 ? ((profit / totalBuyWithGst) * 100).toFixed(1) : '0';

  // Compute 5% vs 18% share in selling
  let sum5 = 0;
  let sum18 = 0;
  items.forEach((it) => {
    const lineWithTax = (it.rate || 0) * (it.qty || 1) * (1 + (it.gst || 0) / 100);
    if (it.gst === 5) sum5 += lineWithTax;
    else if (it.gst === 18) sum18 += lineWithTax;
  });

  const totalGSTSubject = sum5 + sum18;
  const pct5 = totalGSTSubject > 0 ? (sum5 / totalGSTSubject) * 100 : 0;
  const pct18 = totalGSTSubject > 0 ? (sum18 / totalGSTSubject) * 100 : 0;

  // Auto-reverse calculation from targetPrice
  const handleAutoReverseCalculate = () => {
    if (targetPrice <= 0 || totalBuyWithGst <= 0) return;

    const updated = items.map((it) => {
      const itBuyWithGst = (it.buyRate || 0) * (it.qty || 1) * (1 + (it.gst || 0) / 100);
      const weight = itBuyWithGst / totalBuyWithGst;
      const targetForItem = targetPrice * weight;
      const rateExcludingGst = it.qty > 0 ? (targetForItem / (1 + (it.gst || 0) / 100)) / it.qty : 0;
      return {
        ...it,
        rate: Math.round(rateExcludingGst * 100) / 100,
      };
    });

    onItemsChange(updated);
  };

  // Preset quick load
  const loadPreset3KW = () => {
    onTargetPriceChange(180000);
    const presetItems: InvoiceItem[] = [
      {
        id: 1,
        name: 'Solar PV Module DCR (ALMM Bifacial 550Wp)',
        hsn: '85414300',
        gst: 5,
        qty: 6,
        unit: 'NOS',
        buyRate: 11000,
        rate: 13500,
        serialNumbers: 'WAAREE-DCR-550W-01 to 06',
      },
      {
        id: 2,
        name: 'Solar Grid-Tied Inverter 3kW (Polycab / Deye)',
        hsn: '85044090',
        gst: 5,
        qty: 1,
        unit: 'Set',
        buyRate: 24000,
        rate: 32000,
        serialNumbers: 'POLYCAB-INV-3KW-9841',
      },
      {
        id: 3,
        name: 'MMS GI C-Channel Structure (HDG 80 Micron)',
        hsn: '73089030',
        gst: 18,
        qty: 1,
        unit: 'Set',
        buyRate: 12000,
        rate: 17500,
      },
      {
        id: 4,
        name: 'DC Solar Cable 4 sq.mm Copper (Red & Black)',
        hsn: '85446020',
        gst: 18,
        qty: 60,
        unit: 'Mtr.',
        buyRate: 45,
        rate: 65,
      },
      {
        id: 5,
        name: 'ACDB & DCDB Distribution Box with SPD (IP65)',
        hsn: '85371000',
        gst: 18,
        qty: 1,
        unit: 'Set',
        buyRate: 5000,
        rate: 7200,
      },
      {
        id: 6,
        name: 'Chemical Earthing Kit + 2.25M GI Electrode',
        hsn: '83111000',
        gst: 18,
        qty: 2,
        unit: 'Set',
        buyRate: 3200,
        rate: 4800,
      },
      {
        id: 7,
        name: 'Turnkey Installation, Testing & Commissioning Charges',
        hsn: '9954',
        gst: 18,
        qty: 1,
        unit: 'Job',
        buyRate: 8000,
        rate: 12000,
      },
    ];
    onItemsChange(presetItems);
  };

  const handleAddNewStock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStockName.trim()) return;
    onAddStockItem({
      name: newStockName.trim(),
      hsn: newStockHsn.trim() || '85414300',
      gst: Number(newStockGst) || 18,
      defaultBuy: Number(newStockBuy) || 0,
    });
    setNewStockName('');
    setNewStockHsn('');
  };

  return (
    <div className="flex h-full flex-col overflow-y-auto bg-slate-900/90 text-slate-100 p-3 sm:p-4 border-r border-slate-800">
      {/* Target Price Reverse Calculator */}
      <div className="rounded-xl border-2 border-amber-500/70 bg-slate-950 p-3.5 shadow-lg">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
            <Calculator className="h-4 w-4" /> Bill Target Amount
          </label>
          <span className="text-[10px] text-slate-400">Total with GST</span>
        </div>

        <div className="mt-2 flex items-center gap-2">
          <div className="relative flex-1">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-amber-400">
              {currency}
            </span>
            <input
              type="number"
              value={targetPrice || ''}
              onChange={(e) => onTargetPriceChange(Number(e.target.value))}
              placeholder="e.g. 180000"
              className="w-full rounded-lg border border-amber-500/50 bg-slate-900 py-2 pl-8 pr-3 text-lg font-black text-amber-400 focus:border-amber-400 focus:outline-none"
            />
          </div>
          <button
            onClick={handleAutoReverseCalculate}
            title="Auto-calculate selling prices from buying rates"
            className="rounded-lg bg-amber-500 px-3 py-2.5 text-xs font-bold text-slate-950 hover:bg-amber-400 transition flex items-center gap-1"
          >
            <Sparkles className="h-3.5 w-3.5" /> Auto Fill
          </button>
        </div>

        {/* 1-click Preset Template */}
        <div className="mt-2.5 flex items-center justify-between text-[11px]">
          <span className="text-slate-400">Quick Template:</span>
          <button
            onClick={loadPreset3KW}
            className="rounded bg-slate-800 px-2 py-1 text-[10px] font-semibold text-amber-300 hover:bg-slate-700"
          >
            ⚡ Load 3 kW Surya Ghar Kit
          </button>
        </div>

        {/* Stats Grid */}
        <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
          <div className="rounded-lg border border-slate-800 bg-slate-900/80 p-2">
            <div className="text-[10px] text-slate-400">Cost Price (w/GST)</div>
            <div className="mt-0.5 text-sm font-bold text-slate-200">
              {currency} {formatIntegerINR(totalBuyWithGst)}
            </div>
          </div>
          <div className="rounded-lg border border-emerald-900/50 bg-emerald-950/20 p-2">
            <div className="text-[10px] text-emerald-400">Estimated Profit</div>
            <div className="mt-0.5 text-sm font-bold text-emerald-400">
              {currency} {formatIntegerINR(profit)} ({profitPercent}%)
            </div>
          </div>
          <div className="rounded-lg border border-blue-900/40 bg-blue-950/20 p-2">
            <div className="text-[10px] text-blue-300">5% GST Items</div>
            <div className="mt-0.5 text-xs font-bold text-blue-300">
              {currency} {formatIntegerINR(sum5)}
            </div>
          </div>
          <div className="rounded-lg border border-orange-900/40 bg-orange-950/20 p-2">
            <div className="text-[10px] text-orange-300">18% GST Items</div>
            <div className="mt-0.5 text-xs font-bold text-orange-300">
              {currency} {formatIntegerINR(sum18)}
            </div>
          </div>
        </div>

        {/* PM Surya Ghar 70:30 Rule Checker */}
        <div className="mt-3 rounded-lg border border-slate-800 bg-slate-900 p-2.5">
          <div className="flex items-center justify-between text-[11px]">
            <span className="font-semibold text-slate-300 flex items-center gap-1">
              <Sliders className="h-3 w-3 text-amber-400" /> PM Surya Ghar 70:30 Ratio
            </span>
            <span className="font-mono text-[10px] text-slate-400">
              {pct5.toFixed(1)}% / {pct18.toFixed(1)}%
            </span>
          </div>

          {/* Ratio bar */}
          <div className="mt-1.5 flex h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
            <div
              style={{ width: `${pct5}%` }}
              className="bg-emerald-500 transition-all duration-300"
              title={`5% GST Items: ${pct5.toFixed(1)}%`}
            />
            <div
              style={{ width: `${pct18}%` }}
              className="bg-orange-500 transition-all duration-300"
              title={`18% GST Items: ${pct18.toFixed(1)}%`}
            />
          </div>

          <div className="mt-1.5 flex justify-between text-[10px]">
            <span className="text-emerald-400 font-medium">5% Solar PV: {pct5.toFixed(1)}%</span>
            <span className="text-orange-400 font-medium">18% BOS: {pct18.toFixed(1)}%</span>
          </div>

          {/* Feedback status */}
          <div className="mt-2 text-[10px]">
            {items.length === 0 ? (
              <span className="text-slate-500">Add solar items to see compliance</span>
            ) : pct5 >= 68 && pct5 <= 75 ? (
              <div className="flex items-center gap-1 text-emerald-400 font-semibold bg-emerald-950/40 p-1.5 rounded">
                <CheckCircle className="h-3 w-3 shrink-0" />
                Perfect DISCOM Ratio! (Ideal ~70:30)
              </div>
            ) : pct5 < 68 ? (
              <div className="flex items-center gap-1 text-amber-400 font-medium bg-amber-950/40 p-1.5 rounded">
                <AlertTriangle className="h-3 w-3 shrink-0" />
                5% ratio is low ({pct5.toFixed(0)}%). Increase Panel or Inverter share.
              </div>
            ) : (
              <div className="flex items-center gap-1 text-amber-400 font-medium bg-amber-950/40 p-1.5 rounded">
                <Info className="h-3 w-3 shrink-0" />
                5% ratio is high ({pct5.toFixed(0)}%). Balance with structure/installation.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Solar Stock & Equipment Library */}
      <div className="mt-4 flex-1 flex flex-col min-h-0">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Layers className="h-3.5 w-3.5" /> Solar Equipment Catalog
          </h4>
          <span className="text-[10px] text-slate-500">{stockLibrary.length} items</span>
        </div>

        {/* Stock List Scrollable */}
        <div className="flex-1 overflow-y-auto space-y-1 rounded-xl border border-slate-800 bg-slate-950/60 p-2">
          {stockLibrary.map((stk) => (
            <div
              key={stk.name}
              className="group flex items-center justify-between rounded-lg border border-slate-800/80 bg-slate-900/60 p-1.5 text-xs hover:border-amber-500/40 transition"
            >
              <div className="flex-1 overflow-hidden pr-2">
                <div className="truncate font-medium text-slate-200" title={stk.name}>
                  {stk.name}
                </div>
                <div className="text-[10px] text-slate-400">
                  HSN: {stk.hsn} • GST: <b className={stk.gst === 5 ? 'text-emerald-400' : 'text-orange-400'}>{stk.gst}%</b>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    // Add item into active bill
                    const newItem: InvoiceItem = {
                      id: Date.now(),
                      name: stk.name,
                      hsn: stk.hsn,
                      gst: stk.gst,
                      qty: 1,
                      unit: stk.name.includes('Cable') ? 'Mtr.' : stk.name.includes('Service') || stk.name.includes('Charges') ? 'Job' : 'NOS',
                      buyRate: stk.defaultBuy || 1000,
                      rate: Math.round((stk.defaultBuy || 1000) * 1.3),
                      serialNumbers: '',
                    };
                    onItemsChange([...items, newItem]);
                  }}
                  className="rounded bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold text-amber-400 hover:bg-amber-500 hover:text-slate-950"
                  title="Add to Current Invoice"
                >
                  + Add
                </button>
                <button
                  onClick={() => onDeleteStockItem(stk.name)}
                  className="opacity-0 group-hover:opacity-100 p-0.5 text-slate-500 hover:text-rose-400"
                  title="Delete from Library"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Add Custom Stock Item Form */}
        <form onSubmit={handleAddNewStock} className="mt-2 rounded-xl border border-slate-800 bg-slate-950 p-2.5">
          <div className="text-[11px] font-bold text-slate-300 mb-1.5">+ Create Custom Item</div>
          <div className="space-y-1.5">
            <input
              type="text"
              placeholder="Item name (e.g. Adani 540W Mono)"
              value={newStockName}
              onChange={(e) => setNewStockName(e.target.value)}
              className="w-full rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-white focus:border-amber-400 focus:outline-none"
            />
            <div className="grid grid-cols-3 gap-1.5">
              <input
                type="text"
                placeholder="HSN"
                value={newStockHsn}
                onChange={(e) => setNewStockHsn(e.target.value)}
                className="rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-white focus:border-amber-400 focus:outline-none"
              />
              <select
                value={newStockGst}
                onChange={(e) => setNewStockGst(Number(e.target.value))}
                className="rounded border border-slate-700 bg-slate-900 px-1.5 py-1 text-xs text-white focus:border-amber-400 focus:outline-none"
              >
                <option value={5}>5% GST</option>
                <option value={18}>18% GST</option>
                <option value={12}>12% GST</option>
                <option value={0}>0% GST</option>
              </select>
              <input
                type="number"
                placeholder="Buy Rate"
                value={newStockBuy || ''}
                onChange={(e) => setNewStockBuy(Number(e.target.value))}
                className="rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-white focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>
          <button
            type="submit"
            className="mt-2 w-full rounded bg-slate-800 py-1 text-xs font-semibold text-amber-400 hover:bg-slate-700"
          >
            Save to Catalog
          </button>
        </form>
      </div>
    </div>
  );
};
