import React from 'react';
import { DocType, LicenseInfo } from '../types/solar';
import {
  Sun,
  Printer,
  Share2,
  Sliders,
  User,
  Building2,
  ShieldAlert,
  FileText,
  ClipboardList,
  CheckCircle2,
  Landmark,
  Eye,
  EyeOff
} from 'lucide-react';

interface HeaderNavProps {
  docType: DocType;
  onDocTypeChange: (dt: DocType) => void;
  activeSidebarTab: 'calc' | 'customer' | 'firm';
  onSidebarTabChange: (tab: 'calc' | 'customer' | 'firm') => void;
  templateStyle: 1 | 2 | 3;
  onTemplateStyleChange: (tpl: 1 | 2 | 3) => void;
  showBuyRates: boolean;
  onToggleBuyRates: () => void;
  license: LicenseInfo | null;
  monthInvoiceCount: number;
  onOpenAdmin: () => void;
  onOpenLicenseChange: () => void;
  onPrint: () => void;
  onWhatsAppShare: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  docType,
  onDocTypeChange,
  activeSidebarTab,
  onSidebarTabChange,
  templateStyle,
  onTemplateStyleChange,
  showBuyRates,
  onToggleBuyRates,
  license,
  monthInvoiceCount,
  onOpenAdmin,
  onOpenLicenseChange,
  onPrint,
  onWhatsAppShare,
}) => {
  const isTrial = license?.plan === 'Trial';
  const limitStr = isTrial ? `${monthInvoiceCount}/${license.invoiceLimit}` : '∞ Unlimited';

  return (
    <header className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 bg-slate-950 px-4 py-2.5 text-slate-100 select-none print:hidden">
      {/* Brand & Plan Badge */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20">
            <Sun className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm tracking-tight text-white">
                NEXBILL <span className="text-amber-400">SOLAR</span>
              </span>
              <span className="rounded bg-amber-500/20 px-1.5 py-0.2 text-[9px] font-bold text-amber-400 border border-amber-500/30">
                V2.5
              </span>
            </div>
            <div className="text-[10px] text-slate-400 flex items-center gap-1">
              <span>Plan:</span>
              <button
                onClick={onOpenLicenseChange}
                className="font-bold text-amber-400 hover:underline cursor-pointer"
                title="Click to change license key"
              >
                {license?.plan || 'Trial'} ({limitStr}) ↗
              </button>
            </div>
          </div>
        </div>

        {/* Template Style Selector */}
        <div className="hidden lg:flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-900 p-1 text-[11px]">
          <span className="text-[10px] text-slate-500 px-1.5 font-medium">Theme:</span>
          <button
            onClick={() => onTemplateStyleChange(1)}
            className={`rounded px-2 py-0.5 font-medium ${
              templateStyle === 1 ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Clean
          </button>
          <button
            onClick={() => onTemplateStyleChange(2)}
            className={`rounded px-2 py-0.5 font-medium ${
              templateStyle === 2 ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Blue
          </button>
          <button
            onClick={() => onTemplateStyleChange(3)}
            className={`rounded px-2 py-0.5 font-medium ${
              templateStyle === 3 ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Dark Gold
          </button>
        </div>
      </div>

      {/* Document Mode Tabs (Center) */}
      <div className="flex items-center gap-1 rounded-xl border border-slate-800 bg-slate-900 p-1 text-xs">
        <button
          onClick={() => onDocTypeChange('invoice')}
          className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-bold transition ${
            docType === 'invoice'
              ? 'bg-amber-500 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FileText className="h-3.5 w-3.5" />
          Tax Invoice
        </button>

        <button
          onClick={() => onDocTypeChange('quotation')}
          className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-bold transition ${
            docType === 'quotation'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <ClipboardList className="h-3.5 w-3.5" />
          Quotation
        </button>

        <button
          onClick={() => onDocTypeChange('wcc')}
          className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-bold transition ${
            docType === 'wcc'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <CheckCircle2 className="h-3.5 w-3.5" />
          WCC Certificate
        </button>

        <button
          onClick={() => onDocTypeChange('estimate')}
          className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 font-bold transition ${
            docType === 'estimate'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Landmark className="h-3.5 w-3.5" />
          Bank Estimate
        </button>
      </div>

      {/* Action Buttons (Right) */}
      <div className="flex items-center gap-2">
        {/* Toggle Buy Rate visibility */}
        <button
          onClick={onToggleBuyRates}
          className={`flex items-center gap-1 rounded-lg border border-slate-700 px-2.5 py-1.5 text-xs font-semibold ${
            showBuyRates ? 'bg-amber-950/60 text-amber-300 border-amber-600/50' : 'bg-slate-900 text-slate-400'
          }`}
          title="Toggle Buying Cost and Margin column in editor"
        >
          {showBuyRates ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
          <span className="hidden sm:inline">Calc Mode</span>
        </button>

        {/* Sidebar Drawers Switcher */}
        <div className="flex rounded-lg border border-slate-800 bg-slate-900 p-0.5 text-xs">
          <button
            onClick={() => onSidebarTabChange('calc')}
            className={`rounded px-2.5 py-1 flex items-center gap-1 ${
              activeSidebarTab === 'calc' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
            title="Calculator & Stocks"
          >
            <Sliders className="h-3.5 w-3.5" />
            <span className="hidden md:inline">70:30 Calc</span>
          </button>
          <button
            onClick={() => onSidebarTabChange('customer')}
            className={`rounded px-2.5 py-1 flex items-center gap-1 ${
              activeSidebarTab === 'customer' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
            title="Customer Info"
          >
            <User className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Customer</span>
          </button>
          <button
            onClick={() => onSidebarTabChange('firm')}
            className={`rounded px-2.5 py-1 flex items-center gap-1 ${
              activeSidebarTab === 'firm' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
            title="Firm & Bank Settings"
          >
            <Building2 className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Firm</span>
          </button>
        </div>

        {/* Admin Portal Button */}
        <button
          onClick={onOpenAdmin}
          className="rounded-lg border border-amber-500/40 bg-amber-950/30 px-2.5 py-1.5 text-xs font-bold text-amber-400 hover:bg-amber-900/50 flex items-center gap-1"
          title="Owner / Admin License Manager (Password Protected)"
        >
          <ShieldAlert className="h-3.5 w-3.5" />
          <span className="hidden lg:inline">Admin</span>
        </button>

        {/* WhatsApp Share */}
        <button
          onClick={onWhatsAppShare}
          className="rounded-lg border border-emerald-600/50 bg-emerald-950/40 px-2.5 py-1.5 text-xs font-bold text-emerald-300 hover:bg-emerald-900/60 flex items-center gap-1"
          title="Share invoice summary on WhatsApp"
        >
          <Share2 className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">WhatsApp</span>
        </button>

        {/* Print / PDF */}
        <button
          onClick={onPrint}
          className="rounded-lg bg-amber-500 px-3.5 py-1.5 text-xs font-extrabold text-slate-950 hover:bg-amber-400 shadow-md flex items-center gap-1.5"
          title="Print or Save as PDF"
        >
          <Printer className="h-3.5 w-3.5" />
          <span>Print / PDF</span>
        </button>
      </div>
    </header>
  );
};
