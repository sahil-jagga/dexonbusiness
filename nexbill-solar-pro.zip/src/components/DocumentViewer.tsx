import React from 'react';
import {
  DocType,
  InvoiceItem,
  CustomerInfo,
  FirmInfo,
  BankInfo,
  TermsInfo,
  InvoiceMeta,
  WccDetails,
  QuotationDetails,
  StockItem
} from '../types/solar';
import { formatINR, formatIntegerINR, numberToWordsRupees } from '../services/licenseService';
import { Trash2, Plus, Sun, ShieldCheck } from 'lucide-react';

interface DocumentViewerProps {
  docType: DocType;
  templateStyle: 1 | 2 | 3; // 1: Clean, 2: Blue, 3: Dark
  showBuyRates: boolean;
  currency: string;
  items: InvoiceItem[];
  onItemsChange: (items: InvoiceItem[]) => void;
  customer: CustomerInfo;
  onCustomerChange: (c: CustomerInfo) => void;
  firm: FirmInfo;
  bank: BankInfo;
  terms: TermsInfo;
  meta: InvoiceMeta;
  onMetaChange: (m: InvoiceMeta) => void;
  wcc: WccDetails;
  onWccChange: (w: WccDetails) => void;
  quotation: QuotationDetails;
  onQuotationChange: (q: QuotationDetails) => void;
  stockLibrary: StockItem[];
}

export const DocumentViewer: React.FC<DocumentViewerProps> = ({
  docType,
  templateStyle,
  showBuyRates,
  currency,
  items,
  onItemsChange,
  customer,
  firm,
  bank,
  terms,
  meta,
  onMetaChange,
  wcc,
  onWccChange,
  quotation,
  onQuotationChange,
  stockLibrary,
}) => {
  // Calculations
  let totalTaxable = 0;
  let totalCgst = 0;
  let totalSgst = 0;

  const calculatedItems = items.map((it) => {
    const qty = Number(it.qty) || 0;
    const rate = Number(it.rate) || 0;
    const gst = Number(it.gst) || 0;
    const lineTotal = qty * rate;
    const cgst = (lineTotal * (gst / 2)) / 100;
    const sgst = (lineTotal * (gst / 2)) / 100;
    const totalWithTax = lineTotal + cgst + sgst;

    totalTaxable += lineTotal;
    totalCgst += cgst;
    totalSgst += sgst;

    return {
      ...it,
      lineTotal,
      cgst,
      sgst,
      totalWithTax,
    };
  });

  const rawGrandTotal = totalTaxable + totalCgst + totalSgst;
  const grandTotal = Math.round(rawGrandTotal);
  const roundOff = grandTotal - rawGrandTotal;

  // HSN Breakdown
  const hsnBuckets: { [rate: number]: { taxable: number; cgst: number; sgst: number } } = {};
  calculatedItems.forEach((it) => {
    const r = it.gst || 0;
    if (!hsnBuckets[r]) hsnBuckets[r] = { taxable: 0, cgst: 0, sgst: 0 };
    hsnBuckets[r].taxable += it.lineTotal;
    hsnBuckets[r].cgst += it.cgst;
    hsnBuckets[r].sgst += it.sgst;
  });

  // Handlers for Items
  const handleItemChange = (id: number, field: keyof InvoiceItem, val: any) => {
    const updated = items.map((it) => {
      if (it.id !== id) return it;
      const copy: any = { ...it, [field]: val };
      // Auto-fill HSN and GST if item name matches stock
      if (field === 'name') {
        const found = stockLibrary.find((s) => s.name === val);
        if (found) {
          copy.hsn = found.hsn;
          copy.gst = found.gst;
          if (found.defaultBuy && !copy.buyRate) {
            copy.buyRate = found.defaultBuy;
          }
        }
      }
      return copy;
    });
    onItemsChange(updated);
  };

  const handleAddItemRow = () => {
    const newItem: InvoiceItem = {
      id: Date.now(),
      name: '',
      hsn: '85414300',
      gst: 18,
      qty: 1,
      unit: 'NOS',
      buyRate: 1000,
      rate: 1300,
      serialNumbers: '',
    };
    onItemsChange([...items, newItem]);
  };

  const handleDeleteItemRow = (id: number) => {
    onItemsChange(items.filter((it) => it.id !== id));
  };

  // Firm Header Component
  const renderFirmHeader = (theme: 1 | 2 | 3) => {
    const nameColor =
      theme === 1 ? 'text-slate-900' : theme === 2 ? 'text-white' : 'text-amber-400';
    const subColor =
      theme === 1 ? 'text-slate-600' : theme === 2 ? 'text-blue-100' : 'text-slate-300';

    return (
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3.5">
          {firm.logo ? (
            <img
              src={firm.logo}
              alt="Logo"
              className="h-16 w-28 object-contain rounded bg-white/10 p-1"
            />
          ) : (
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-amber-500 text-slate-950 shadow-md">
              <Sun className="h-8 w-8" />
            </div>
          )}
          <div>
            <h1 className={`text-xl font-black tracking-tight ${nameColor} leading-tight`}>
              {firm.name}
            </h1>
            <p className={`text-[10px] font-semibold ${subColor} mt-0.5`}>
              {firm.tagline || 'Solar Energy Solutions | PM Surya Ghar Empanelled Vendor'}
            </p>
            <p className={`text-[10px] ${subColor} leading-relaxed`}>{firm.address}</p>
            <p className={`text-[10px] ${subColor}`}>
              <b>Tel:</b> {firm.mobile} | <b>GSTIN:</b> {firm.gstin} {firm.pan ? `| PAN: ${firm.pan}` : ''}
              {firm.email ? ` | ${firm.email}` : ''}
            </p>
          </div>
        </div>

        <div className="text-right shrink-0">
          <div
            className={`inline-block rounded-lg px-3 py-1 text-xs font-black uppercase tracking-wider ${
              theme === 1
                ? 'bg-slate-900 text-amber-400'
                : theme === 2
                ? 'bg-white/20 text-white border border-white/30 backdrop-blur'
                : 'bg-amber-400 text-slate-950'
            }`}
          >
            {docType === 'invoice'
              ? 'TAX INVOICE'
              : docType === 'quotation'
              ? 'SOLAR QUOTATION'
              : docType === 'wcc'
              ? 'WORK COMPLETION'
              : 'BANK LOAN ESTIMATE'}
          </div>
          <div className={`mt-1 text-[10px] font-semibold ${subColor}`}>
            {meta.copyType || 'Original for Recipient'}
          </div>
        </div>
      </div>
    );
  };

  // Meta Information Bar
  const renderMetaRow = (bgClass: string, textClass: string) => {
    return (
      <div className={`mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg ${bgClass} px-3 py-2 text-[10px] ${textClass}`}>
        <div>
          <b>Doc No:</b>{' '}
          <input
            type="text"
            value={meta.invNo}
            onChange={(e) => onMetaChange({ ...meta, invNo: e.target.value })}
            placeholder="JE/26-27/001"
            className="border-b border-dashed border-current bg-transparent font-bold focus:outline-none"
          />
        </div>
        <div>
          <b>Date:</b>{' '}
          <input
            type="date"
            value={meta.date}
            onChange={(e) => onMetaChange({ ...meta, date: e.target.value })}
            className="border-b border-dashed border-current bg-transparent font-bold focus:outline-none"
          />
        </div>
        <div>
          <b>E-Way Bill:</b>{' '}
          <input
            type="text"
            value={meta.eway}
            onChange={(e) => onMetaChange({ ...meta, eway: e.target.value })}
            placeholder="Optional"
            className="border-b border-dashed border-current bg-transparent focus:outline-none w-24"
          />
        </div>
        <div>
          <b>Place of Supply:</b> {meta.placeOfSupply || 'Rajasthan (08)'}
        </div>
        <div>
          <b>Reverse Charge:</b> {meta.reverseCharge || 'No'}
        </div>
      </div>
    );
  };

  // Customer Billed / Shipped Box
  const renderCustomerBoxes = (borderClass: string, headerClass: string) => {
    return (
      <div className="mt-3 grid grid-cols-2 gap-3 text-[10px]">
        <div className={`rounded-lg border ${borderClass} p-2.5`}>
          <div className={`font-bold uppercase tracking-wider mb-1 ${headerClass}`}>
            Billed To (Site Owner)
          </div>
          <div className="space-y-0.5 leading-relaxed">
            <div className="font-bold text-xs">{customer.name || '—'}</div>
            {customer.relation && <div>{customer.relation}</div>}
            <div className="whitespace-pre-line">{customer.address || '—'}</div>
            {customer.mobile && <div><b>Mobile:</b> {customer.mobile}</div>}
            {customer.aadhar && <div><b>Aadhaar:</b> {customer.aadhar}</div>}
            {customer.appNo && <div className="text-amber-600 font-semibold"><b>App No (Surya Ghar):</b> {customer.appNo}</div>}
            {customer.consumerNo && <div><b>K-No / Consumer No:</b> {customer.consumerNo}</div>}
            {customer.gstin && <div><b>GSTIN:</b> {customer.gstin}</div>}
          </div>
        </div>

        <div className={`rounded-lg border ${borderClass} p-2.5`}>
          <div className={`font-bold uppercase tracking-wider mb-1 ${headerClass}`}>
            Shipped To (Installation Site)
          </div>
          <div className="space-y-0.5 leading-relaxed">
            <div className="font-bold text-xs">{customer.name || '—'}</div>
            <div className="whitespace-pre-line">{customer.address || 'Same as Billing Address'}</div>
            {customer.sanctionLoad && <div><b>Sanctioned Load:</b> {customer.sanctionLoad}</div>}
            {customer.mobile && <div><b>Contact:</b> {customer.mobile}</div>}
            <div className="text-slate-500 italic mt-1">Solar Rooftop On-Grid Net-Metered Site</div>
          </div>
        </div>
      </div>
    );
  };

  // Main Items Table
  const renderItemsTable = (thClass: string, totalRowClass: string) => {
    return (
      <div className="mt-3 overflow-x-auto">
        {/* Datalist for fast item stock selection */}
        <datalist id="stock-datalist">
          {stockLibrary.map((s) => (
            <option key={s.name} value={s.name} />
          ))}
        </datalist>

        <table className="w-full border-collapse text-[10px]">
          <thead>
            <tr className={thClass}>
              <th className="py-2 px-1 text-center w-6">#</th>
              <th className="py-2 px-2 text-left">Description of Goods / Services</th>
              <th className="py-2 px-1.5 text-center w-16">HSN/SAC</th>
              <th className="py-2 px-1 text-center w-12">GST%</th>
              <th className="py-2 px-1 text-center w-12">Qty</th>
              <th className="py-2 px-1 text-center w-12">Unit</th>
              {showBuyRates && (
                <th className="py-2 px-1 text-right w-16 bg-amber-900/20 text-amber-300">
                  Buy Rate
                </th>
              )}
              <th className="py-2 px-1.5 text-right w-18">Rate ({currency})</th>
              <th className="py-2 px-1.5 text-right w-16">CGST</th>
              <th className="py-2 px-1.5 text-right w-16">SGST</th>
              <th className="py-2 px-2 text-right w-20">Total ({currency})</th>
              <th className="py-2 px-1 w-6 print:hidden"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {calculatedItems.map((it, idx) => (
              <tr key={it.id} className="hover:bg-slate-50/50">
                <td className="py-1.5 px-1 text-center text-slate-400 font-medium">{idx + 1}</td>
                <td className="py-1 px-2">
                  <input
                    type="text"
                    list="stock-datalist"
                    value={it.name}
                    placeholder="Enter item description..."
                    onChange={(e) => handleItemChange(it.id, 'name', e.target.value)}
                    className="w-full bg-transparent font-medium text-slate-900 focus:outline-none"
                  />
                  <input
                    type="text"
                    value={it.serialNumbers || ''}
                    placeholder="Serial no. / Make details (optional)"
                    onChange={(e) => handleItemChange(it.id, 'serialNumbers', e.target.value)}
                    className="w-full bg-transparent text-[9px] text-slate-500 font-mono focus:outline-none"
                  />
                </td>
                <td className="py-1 px-1.5 text-center">
                  <input
                    type="text"
                    value={it.hsn}
                    onChange={(e) => handleItemChange(it.id, 'hsn', e.target.value)}
                    className="w-full text-center bg-transparent focus:outline-none font-mono"
                  />
                </td>
                <td className="py-1 px-1 text-center">
                  <select
                    value={it.gst}
                    onChange={(e) => handleItemChange(it.id, 'gst', Number(e.target.value))}
                    className="bg-transparent text-center font-bold focus:outline-none"
                  >
                    <option value={5}>5%</option>
                    <option value={18}>18%</option>
                    <option value={12}>12%</option>
                    <option value={0}>0%</option>
                  </select>
                </td>
                <td className="py-1 px-1 text-center">
                  <input
                    type="number"
                    value={it.qty || ''}
                    onChange={(e) => handleItemChange(it.id, 'qty', Number(e.target.value))}
                    className="w-full text-center bg-transparent font-bold focus:outline-none"
                  />
                </td>
                <td className="py-1 px-1 text-center">
                  <select
                    value={it.unit}
                    onChange={(e) => handleItemChange(it.id, 'unit', e.target.value)}
                    className="bg-transparent text-center focus:outline-none"
                  >
                    <option value="NOS">NOS</option>
                    <option value="Pcs.">Pcs.</option>
                    <option value="Set">Set</option>
                    <option value="Mtr.">Mtr.</option>
                    <option value="Kg.">Kg.</option>
                    <option value="Job">Job</option>
                  </select>
                </td>
                {showBuyRates && (
                  <td className="py-1 px-1 text-right bg-amber-50/50">
                    <input
                      type="number"
                      value={it.buyRate || ''}
                      onChange={(e) => handleItemChange(it.id, 'buyRate', Number(e.target.value))}
                      className="w-full text-right bg-transparent text-amber-800 font-bold focus:outline-none"
                    />
                  </td>
                )}
                <td className="py-1 px-1.5 text-right font-medium">
                  <input
                    type="number"
                    value={it.rate || ''}
                    onChange={(e) => handleItemChange(it.id, 'rate', Number(e.target.value))}
                    className="w-full text-right bg-transparent font-bold focus:outline-none"
                  />
                </td>
                <td className="py-1 px-1.5 text-right text-emerald-700 font-medium">
                  {formatINR(it.cgst)}
                </td>
                <td className="py-1 px-1.5 text-right text-emerald-700 font-medium">
                  {formatINR(it.sgst)}
                </td>
                <td className="py-1 px-2 text-right font-extrabold text-slate-900">
                  {formatINR(it.totalWithTax)}
                </td>
                <td className="py-1 px-1 text-center print:hidden">
                  <button
                    onClick={() => handleDeleteItemRow(it.id)}
                    className="text-slate-400 hover:text-rose-500 p-0.5"
                    title="Delete row"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-slate-300 font-bold bg-slate-50">
              <td colSpan={showBuyRates ? 7 : 6} className="py-1.5 px-2 text-right">
                Taxable Subtotal:
              </td>
              <td className="py-1.5 px-1.5 text-right">{formatINR(totalTaxable)}</td>
              <td className="py-1.5 px-1.5 text-right text-emerald-700">{formatINR(totalCgst)}</td>
              <td className="py-1.5 px-1.5 text-right text-emerald-700">{formatINR(totalSgst)}</td>
              <td className="py-1.5 px-2 text-right font-extrabold">{formatINR(rawGrandTotal)}</td>
              <td className="print:hidden"></td>
            </tr>

            {roundOff !== 0 && (
              <tr className="text-[9px] text-slate-500">
                <td colSpan={showBuyRates ? 9 : 8} className="py-0.5 px-2 text-right">
                  Round Off (+/-):
                </td>
                <td colSpan={2} className="py-0.5 px-2 text-right font-mono">
                  {roundOff > 0 ? `+${roundOff.toFixed(2)}` : roundOff.toFixed(2)}
                </td>
                <td className="print:hidden"></td>
              </tr>
            )}

            <tr className={totalRowClass}>
              <td colSpan={showBuyRates ? 6 : 5} className="py-2.5 px-3 text-left font-normal text-[10px]">
                <div className="font-semibold text-slate-700">Amount in Words:</div>
                <div className="font-bold italic text-slate-900 mt-0.5">
                  {numberToWordsRupees(grandTotal)}
                </div>
              </td>
              <td colSpan={2} className="py-2.5 px-2 text-right uppercase tracking-wider text-xs">
                Grand Total ({currency}):
              </td>
              <td colSpan={3} className="py-2.5 px-3 text-right font-black text-base">
                {currency} {formatIntegerINR(grandTotal)}
              </td>
              <td className="print:hidden"></td>
            </tr>
          </tfoot>
        </table>

        {/* Add Row Button in Table */}
        <div className="mt-2 flex justify-start print:hidden">
          <button
            onClick={handleAddItemRow}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 shadow-sm"
          >
            <Plus className="h-3.5 w-3.5 text-emerald-600" /> + Add Row
          </button>
        </div>
      </div>
    );
  };

  // GST Breakdown Table
  const renderGstBreakdown = (thClass: string) => {
    return (
      <div className="mt-3 flex justify-end">
        <table className="border-collapse text-[9px] min-w-[280px]">
          <thead>
            <tr className={thClass}>
              <th className="py-1 px-2 text-center">Tax Rate</th>
              <th className="py-1 px-2 text-right">Taxable ({currency})</th>
              <th className="py-1 px-2 text-right">CGST</th>
              <th className="py-1 px-2 text-right">SGST</th>
              <th className="py-1 px-2 text-right">Total Tax</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {Object.entries(hsnBuckets)
              .sort((a, b) => Number(a[0]) - Number(b[0]))
              .map(([rate, vals]) => (
                <tr key={rate}>
                  <td className="py-1 px-2 text-center font-bold">{rate}%</td>
                  <td className="py-1 px-2 text-right">{formatINR(vals.taxable)}</td>
                  <td className="py-1 px-2 text-right text-emerald-700">{formatINR(vals.cgst)}</td>
                  <td className="py-1 px-2 text-right text-emerald-700">{formatINR(vals.sgst)}</td>
                  <td className="py-1 px-2 text-right font-bold text-slate-900">
                    {formatINR(vals.cgst + vals.sgst)}
                  </td>
                </tr>
              ))}
          </tbody>
          <tfoot>
            <tr className="border-t font-bold bg-slate-100">
              <td className="py-1 px-2 text-center">Total</td>
              <td className="py-1 px-2 text-right">{formatINR(totalTaxable)}</td>
              <td className="py-1 px-2 text-right text-emerald-700">{formatINR(totalCgst)}</td>
              <td className="py-1 px-2 text-right text-emerald-700">{formatINR(totalSgst)}</td>
              <td className="py-1 px-2 text-right font-extrabold text-slate-950">
                {formatINR(totalCgst + totalSgst)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    );
  };

  // Bank & Footer Signatures
  const renderFooter = (bankBgClass: string, sigColor: string) => {
    return (
      <div className="mt-4 pt-3 border-t border-slate-300 text-[10px]">
        {/* Bank Bar */}
        <div className={`rounded-lg ${bankBgClass} p-2 flex flex-wrap items-center justify-between gap-2`}>
          <div>
            <b>Bank Details:</b> {bank.bankName} | <b>A/C No:</b> {bank.accountNo} | <b>IFSC:</b>{' '}
            {bank.ifsc} | <b>Branch:</b> {bank.branch}
          </div>
          {bank.upiId && (
            <div className="font-semibold text-emerald-700">
              <b>UPI / QR:</b> {bank.upiId}
            </div>
          )}
        </div>

        {/* Declaration & T&C */}
        <div className="mt-2 space-y-1 text-[9px] text-slate-600">
          <div>
            <b>Declaration:</b> {terms.declaration}
          </div>
          <div>
            <b>Terms & Conditions:</b> {terms.tnc}
          </div>
        </div>

        {/* Signatures */}
        <div className="mt-8 flex items-end justify-between pt-4">
          <div className="text-center">
            <div className={`w-40 border-t ${sigColor} mb-1`} />
            <div className="font-semibold text-slate-700">Customer / Receiver Signature</div>
          </div>

          <div className="text-center">
            <div className="text-xs font-bold text-slate-900 mb-8">For {firm.name}</div>
            <div className={`w-48 border-t ${sigColor} mb-1`} />
            <div className="font-semibold text-slate-700">Authorised Signatory</div>
          </div>
        </div>
      </div>
    );
  };

  // -------------------------------------------------------------
  // Render: WCC (Work Completion Certificate)
  // -------------------------------------------------------------
  if (docType === 'wcc') {
    return (
      <div className="mx-auto w-full max-w-4xl bg-white text-slate-900 p-8 sm:p-12 shadow-2xl rounded-xl print:shadow-none print:p-0">
        {/* WCC Header */}
        <div className="border-b-2 border-slate-900 pb-4 text-center">
          <h1 className="text-2xl font-black text-slate-900 uppercase tracking-tight">
            {firm.name}
          </h1>
          <p className="text-xs text-slate-600 font-medium mt-1">
            {firm.tagline || 'Solar Energy Solutions | PM Surya Ghar: Muft Bijli Yojana Vendor'}
          </p>
          <p className="text-xs text-slate-600">{firm.address}</p>
          <p className="text-xs text-slate-600">
            GSTIN: <b>{firm.gstin}</b> | Phone: <b>{firm.mobile}</b>
          </p>
        </div>

        {/* Title */}
        <div className="mt-6 text-center">
          <span className="inline-block border-b-2 border-slate-900 pb-1 text-base font-extrabold uppercase tracking-wider text-slate-900">
            Work Completion Certificate (WCC)
          </span>
          <p className="mt-1 text-xs text-slate-500">
            As per Ministry of New & Renewable Energy (MNRE) & PM Surya Ghar Guidelines
          </p>
        </div>

        <p className="mt-6 text-xs text-slate-700 leading-relaxed">
          This is to solemnly certify that <b>{firm.name}</b> (GSTIN: {firm.gstin}), having its office at {firm.address}, has successfully supplied, erected, tested, and commissioned the Grid-Connected Solar Rooftop Power Plant as per the following specifications:
        </p>

        {/* Detailed Table Grid */}
        <div className="mt-6 divide-y divide-slate-200 border border-slate-300 rounded-lg text-xs">
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">1. EPC Vendor / Installer:</div>
            <div className="flex-1 font-semibold">{firm.name}</div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">2. Beneficiary / Site Owner:</div>
            <div className="flex-1 font-semibold">{customer.name || '—'} {customer.relation ? `(${customer.relation})` : ''}</div>
          </div>
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">3. Installation Site Address:</div>
            <div className="flex-1 whitespace-pre-line">{customer.address || '—'}</div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">4. Solar Plant Capacity:</div>
            <div className="flex-1 font-bold text-emerald-800 flex items-center gap-1">
              <input
                type="text"
                value={wcc.plantCapacityKw}
                onChange={(e) => onWccChange({ ...wcc, plantCapacityKw: e.target.value })}
                placeholder="e.g. 3.00 kW"
                className="border-b border-dashed border-current bg-transparent focus:outline-none w-32 font-bold"
              />
              <span>(On-Grid Rooftop)</span>
            </div>
          </div>
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">5. Solar PV Module Make & Type:</div>
            <div className="flex-1 flex gap-2">
              <input
                type="text"
                value={wcc.panelMake}
                onChange={(e) => onWccChange({ ...wcc, panelMake: e.target.value })}
                placeholder="e.g. Waaree Bifacial DCR 550Wp"
                className="w-full border-b border-dashed border-current bg-transparent focus:outline-none font-semibold"
              />
            </div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">6. Solar Inverter Make & Serial:</div>
            <div className="flex-1 flex gap-2">
              <input
                type="text"
                value={wcc.inverterMake}
                onChange={(e) => onWccChange({ ...wcc, inverterMake: e.target.value })}
                placeholder="e.g. Polycab 3kW / Deye String Inverter"
                className="w-full border-b border-dashed border-current bg-transparent focus:outline-none font-semibold"
              />
            </div>
          </div>
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">7. Electricity Consumer K-No.:</div>
            <div className="flex-1 font-mono font-semibold">{customer.consumerNo || '—'}</div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">8. PM Surya Ghar App No.:</div>
            <div className="flex-1 font-mono font-bold text-amber-700">{customer.appNo || '—'}</div>
          </div>
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">9. Aadhaar Number:</div>
            <div className="flex-1 font-mono">{customer.aadhar || '—'}</div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">10. Work Completion Date:</div>
            <div className="flex-1">
              <input
                type="date"
                value={wcc.completionDate}
                onChange={(e) => onWccChange({ ...wcc, completionDate: e.target.value })}
                className="border-b border-dashed border-current bg-transparent font-bold focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Declaration Notice */}
        <div className="mt-6 rounded-lg border border-slate-300 bg-slate-50 p-4 text-[11px] leading-relaxed text-slate-700">
          <p>
            <b>Customer Undertaking:</b> I hereby confirm that the solar plant has been installed at my premises in full working condition with all necessary safety equipment including Earth Electrode, ACDB, DCDB, and Lightning Arrester. The system is ready for net-metering synchronization with DISCOM.
          </p>
        </div>

        {/* Dual Signature */}
        <div className="mt-14 flex items-end justify-between text-xs">
          <div className="text-center">
            <div className="w-48 border-t-2 border-slate-800 mb-1" />
            <div className="font-bold text-slate-800">Signature of Site Owner</div>
            <div className="text-[10px] text-slate-500">Name: {customer.name || 'Consumer'}</div>
          </div>

          <div className="text-center">
            <div className="text-xs font-bold text-slate-900 mb-10">For {firm.name}</div>
            <div className="w-48 border-t-2 border-slate-800 mb-1" />
            <div className="font-bold text-slate-800">Authorised Signatory</div>
            <div className="text-[10px] text-slate-500">With Stamp & Date</div>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // Render: Solar Quotation & Payback Proposal
  // -------------------------------------------------------------
  if (docType === 'quotation') {
    return (
      <div className="mx-auto w-full max-w-4xl bg-white text-slate-900 p-8 shadow-2xl rounded-xl print:shadow-none print:p-0">
        {/* Header */}
        <div className="rounded-xl bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 p-6 text-white shadow-md">
          {renderFirmHeader(2)}
        </div>

        {renderMetaRow('bg-emerald-50 text-emerald-950', 'text-emerald-950')}
        {renderCustomerBoxes('border-emerald-200 bg-emerald-50/30', 'text-emerald-800')}

        {/* Quotation Solar ROI Banner */}
        <div className="mt-4 rounded-xl border border-emerald-300 bg-emerald-50 p-4">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-900 mb-2 flex items-center gap-1.5">
            <Sun className="h-4 w-4 text-emerald-700" /> PM Surya Ghar Expected Benefits & Subsidy
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="rounded-lg bg-white p-2.5 border border-emerald-200">
              <div className="text-[10px] text-slate-500">Plant Capacity</div>
              <div className="text-sm font-bold text-emerald-800">{quotation.plantCapacityKw || '3 kW'}</div>
            </div>
            <div className="rounded-lg bg-white p-2.5 border border-emerald-200">
              <div className="text-[10px] text-slate-500">Annual Generation</div>
              <div className="text-sm font-bold text-emerald-800">
                ~{quotation.annualGenerationUnits || '4,300'} Units/Yr
              </div>
            </div>
            <div className="rounded-lg bg-white p-2.5 border border-emerald-200">
              <div className="text-[10px] text-slate-500">Annual Bill Savings</div>
              <div className="text-sm font-bold text-emerald-800">
                ~{currency} {formatIntegerINR(quotation.annualSavingsRs || 34400)}
              </div>
            </div>
            <div className="rounded-lg bg-white p-2.5 border border-emerald-200">
              <div className="text-[10px] text-slate-500">Direct Central Subsidy</div>
              <div className="text-sm font-extrabold text-amber-600">
                {currency} {formatIntegerINR(quotation.subsidyAmount || 78000)}
              </div>
            </div>
          </div>
        </div>

        {/* Items Table */}
        {renderItemsTable(
          'bg-emerald-800 text-white font-bold',
          'bg-emerald-100 text-emerald-950 font-extrabold border-t-2 border-emerald-600'
        )}

        {renderGstBreakdown('bg-emerald-800 text-white font-bold')}
        {renderFooter('bg-emerald-50 text-emerald-950', 'border-emerald-800')}
      </div>
    );
  }

  // -------------------------------------------------------------
  // Render: Bank Loan Margin Money Estimate
  // -------------------------------------------------------------
  if (docType === 'estimate') {
    return (
      <div className="mx-auto w-full max-w-4xl bg-white text-slate-900 p-8 shadow-2xl rounded-xl print:shadow-none print:p-0">
        <div className="rounded-xl border-t-4 border-indigo-700 bg-slate-50 p-5 shadow-sm">
          {renderFirmHeader(1)}
        </div>

        {renderMetaRow('bg-indigo-50 text-indigo-950', 'text-indigo-950')}
        {renderCustomerBoxes('border-indigo-200 bg-indigo-50/20', 'text-indigo-800')}

        <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-2.5 text-[11px] text-amber-900 leading-relaxed font-medium text-center">
          <b>NOTE FOR BANK (SBI / PNB / BOB Solar Loan):</b> This is an official proforma cost estimate for the purpose of solar rooftop bank loan appraisal and margin money determination. Subsidy of up to ₹78,000 will be credited directly to consumer's bank account under PM Surya Ghar Yojana.
        </div>

        {renderItemsTable(
          'bg-indigo-900 text-white font-bold',
          'bg-indigo-100 text-indigo-950 font-extrabold border-t-2 border-indigo-700'
        )}

        {renderGstBreakdown('bg-indigo-900 text-white font-bold')}
        {renderFooter('bg-indigo-50 text-indigo-950', 'border-indigo-900')}
      </div>
    );
  }

  // -------------------------------------------------------------
  // Render: TAX INVOICE (3 Professional Themes)
  // -------------------------------------------------------------
  if (templateStyle === 2) {
    // Theme 2: Corporate Blue
    return (
      <div className="mx-auto w-full max-w-4xl bg-white text-slate-900 shadow-2xl rounded-xl overflow-hidden print:shadow-none print:rounded-none">
        <div className="bg-gradient-to-r from-blue-950 via-blue-900 to-indigo-950 p-6 text-white">
          {renderFirmHeader(2)}
        </div>
        <div className="h-1.5 bg-amber-400" />
        <div className="p-6">
          {renderMetaRow('bg-blue-50 text-blue-950', 'text-blue-950')}
          {renderCustomerBoxes('border-blue-200 bg-blue-50/30', 'text-blue-800')}
          {renderItemsTable(
            'bg-blue-900 text-white font-bold',
            'bg-blue-100 text-blue-950 font-extrabold border-t-2 border-blue-600'
          )}
          {renderGstBreakdown('bg-blue-900 text-white font-bold')}
          {renderFooter('bg-blue-50 text-blue-950', 'border-blue-900')}
        </div>
      </div>
    );
  }

  if (templateStyle === 3) {
    // Theme 3: Midnight Dark & Gold (Solar Tech)
    return (
      <div className="mx-auto w-full max-w-4xl bg-slate-900 text-slate-100 shadow-2xl rounded-xl overflow-hidden print:bg-white print:text-slate-900 print:shadow-none">
        <div className="bg-slate-950 p-6 border-b-2 border-amber-400">
          {renderFirmHeader(3)}
        </div>
        <div className="p-6">
          {renderMetaRow('bg-slate-950 text-slate-200', 'text-slate-200')}
          {renderCustomerBoxes('border-slate-800 bg-slate-950/50', 'text-amber-400')}
          {renderItemsTable(
            'bg-slate-950 text-amber-400 font-bold',
            'bg-amber-400 text-slate-950 font-extrabold border-t-2 border-amber-500'
          )}
          {renderGstBreakdown('bg-slate-950 text-amber-400 font-bold')}
          {renderFooter('bg-slate-950 text-slate-300', 'border-amber-400')}
        </div>
      </div>
    );
  }

  // Theme 1: Clean Minimal White
  return (
    <div className="mx-auto w-full max-w-4xl bg-white text-slate-900 p-6 sm:p-8 shadow-2xl rounded-xl print:shadow-none print:p-0">
      <div className="border-b-4 border-slate-900 pb-4">
        {renderFirmHeader(1)}
      </div>
      {renderMetaRow('bg-slate-100 text-slate-800', 'text-slate-800')}
      {renderCustomerBoxes('border-slate-300 bg-slate-50/50', 'text-slate-900')}
      {renderItemsTable(
        'bg-slate-900 text-white font-bold',
        'bg-slate-900 text-amber-400 font-extrabold border-t-2 border-slate-800'
      )}
      {renderGstBreakdown('bg-slate-900 text-white font-bold')}
      {renderFooter('bg-slate-100 text-slate-800', 'border-slate-900')}
    </div>
  );
};
