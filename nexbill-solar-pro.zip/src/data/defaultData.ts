import { StockItem, FirmInfo, BankInfo, TermsInfo, CustomerInfo } from '../types/solar';

export const DEFAULT_STOCKS: StockItem[] = [
  { name: 'Solar PV Module DCR (ALMM Bifacial 550Wp)', hsn: '85414300', gst: 5, defaultBuy: 11000 },
  { name: 'Solar PV Module Non-DCR (Mono PERC)', hsn: '85414300', gst: 5, defaultBuy: 8500 },
  { name: 'Solar Grid-Tied Inverter 3kW (Polycab / Deye)', hsn: '85044090', gst: 5, defaultBuy: 24000 },
  { name: 'Solar Grid-Tied Inverter 5kW (Polycab / Growatt)', hsn: '85044090', gst: 5, defaultBuy: 33000 },
  { name: 'MMS GI C-Channel Structure (HDG 80 Micron)', hsn: '73089030', gst: 18, defaultBuy: 12000 },
  { name: 'C-Channel 4" & 3" HDG (GI)', hsn: '73063090', gst: 18, defaultBuy: 4500 },
  { name: 'Base Plate & Hardware Kit 150x150x6 MM', hsn: '73061011', gst: 18, defaultBuy: 2200 },
  { name: 'DC Solar Cable 4 sq.mm Copper (Red & Black)', hsn: '85446020', gst: 18, defaultBuy: 3500 },
  { name: 'AC Armoured Multistrand Cable 4 Core Copper', hsn: '85446020', gst: 18, defaultBuy: 3200 },
  { name: 'ACDB Distribution Box with SPD (IP65)', hsn: '85371000', gst: 18, defaultBuy: 2800 },
  { name: 'DCDB Distribution Box with SPD (IP65)', hsn: '85371000', gst: 18, defaultBuy: 2600 },
  { name: 'Net Meter Box 1-Phase / 3-Phase Discom Standard', hsn: '85371000', gst: 18, defaultBuy: 1800 },
  { name: 'Lightning Arrester (Copper Bonded with Spike)', hsn: '85354010', gst: 18, defaultBuy: 1600 },
  { name: 'Earthing Electrode 2.25 Mtr (Pure Copper Coated)', hsn: '83111000', gst: 18, defaultBuy: 3200 },
  { name: 'Backfill Chemical Compound Bag 25 KG', hsn: '73089090', gst: 18, defaultBuy: 1100 },
  { name: 'Heavy Duty PVC Conduit Pipe & Accessories', hsn: '392690', gst: 18, defaultBuy: 1500 },
  { name: 'Turnkey Installation, Testing & Commissioning Charges', hsn: '9954', gst: 18, defaultBuy: 8000 },
  { name: 'Net Metering Discom Documentation & Liasioning Service', hsn: '9983', gst: 18, defaultBuy: 3000 },
];

export const DEFAULT_FIRM: FirmInfo = {
  name: 'JAGGA ENTERPRISES & CO.',
  address: 'Vinoba Basti 390B, Near TLT Coaching Centre, Sri Ganganagar, Rajasthan - 335001',
  mobile: '94298-42000 | 94283-42000',
  gstin: '08ERPPK7078L1ZS',
  pan: 'ERPPK7078L',
  email: 'jaggaenterprises.solar@gmail.com',
  tagline: 'Solar Energy Solutions | PM Surya Ghar: Muft Bijli Yojana Empanelled Vendor',
  logo: '',
};

export const DEFAULT_BANK: BankInfo = {
  bankName: 'Punjab National Bank',
  accountNo: '6156002100006195',
  ifsc: 'PUNB0615600',
  branch: 'Sadhuali Cantt, Sri Ganganagar',
  upiId: '9429842000@pnb',
};

export const DEFAULT_TERMS: TermsInfo = {
  declaration:
    'We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct. All solar PV modules carry 25 years performance warranty, and solar inverters carry 5-8 years manufacturer warranty. PM Surya Ghar subsidy is directly credited by Govt. of India to customer bank account.',
  tnc: '1. E.&O.E. (Errors & Omissions Excepted). 2. Goods once sold will not be returned or exchanged. 3. Subject to Sri Ganganagar Jurisdiction only. 4. Grid connectivity and Net Meter sync subject to DISCOM policy.',
};

export const DEFAULT_CUSTOMER: CustomerInfo = {
  name: 'Sh. Rajesh Kumar Verma',
  relation: 'S/O Rameshwar Dayal Verma',
  address: 'House No. 44, Purani Abadi, Ward No. 12, Sri Ganganagar, Rajasthan - 335001',
  mobile: '98290-XXXXX',
  aadhar: 'XXXX-XXXX-8941',
  appNo: 'RJ-SG-2026-789104',
  consumerNo: '1402/2390/4910',
  sanctionLoad: '3.00 kW',
  gstin: '',
};

export const PM_SURYA_GHAR_SUBSIDY_TABLE = [
  { kw: 1, centralSubsidy: 30000, recommendedCost: 65000 },
  { kw: 2, centralSubsidy: 60000, recommendedCost: 125000 },
  { kw: 3, centralSubsidy: 78000, recommendedCost: 175000 },
  { kw: 4, centralSubsidy: 78000, recommendedCost: 220000 },
  { kw: 5, centralSubsidy: 78000, recommendedCost: 265000 },
];
