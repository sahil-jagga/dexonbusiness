export interface InvoiceItem {
  id: number;
  name: string;
  hsn: string;
  gst: number; // 0, 5, 12, 18
  qty: number;
  unit: string; // Pcs., NOS, Set, Mtr., Kg., Job
  buyRate: number; // Buying price without GST
  rate: number; // Selling price without GST
  serialNumbers?: string;
  lineTotal?: number;
  cgst?: number;
  sgst?: number;
  totalWithTax?: number;
}

export interface CustomerInfo {
  name: string;
  relation: string; // S/O or W/O
  address: string;
  mobile: string;
  aadhar: string;
  appNo: string; // PM Surya Ghar Application No
  consumerNo: string; // Discom K-Number / Consumer No
  sanctionLoad: string; // e.g. 5 KW
  gstin: string; // Optional B2B
}

export interface FirmInfo {
  name: string;
  address: string;
  mobile: string;
  gstin: string;
  email: string;
  tagline: string;
  logo: string;
  pan: string;
}

export interface BankInfo {
  bankName: string;
  accountNo: string;
  ifsc: string;
  branch: string;
  upiId?: string;
}

export interface TermsInfo {
  declaration: string;
  tnc: string;
}

export type DocType = 'invoice' | 'quotation' | 'wcc' | 'estimate';

export interface InvoiceMeta {
  invNo: string;
  date: string;
  eway: string;
  quotRef: string;
  placeOfSupply: string;
  reverseCharge: string;
  copyType: 'Original for Recipient' | 'Duplicate for Transporter' | 'Triplicate for Supplier';
}

export interface WccDetails {
  plantCapacityKw: string;
  inverterMake: string;
  inverterSerial: string;
  panelMake: string;
  panelWattage: string;
  panelCount: string;
  completionDate: string;
  discomName: string;
}

export interface QuotationDetails {
  plantCapacityKw: string;
  annualGenerationUnits: number;
  annualSavingsRs: number;
  subsidyAmount: number;
  paybackYears: number;
}

export interface StockItem {
  name: string;
  hsn: string;
  gst: number;
  defaultBuy?: number;
}

export interface LicenseInfo {
  key: string;
  clientName: string;
  plan: 'Trial' | 'Pro' | 'Business';
  expiry: string;
  invoiceLimit: number;
  isActive: boolean;
  totalInvoicesGenerated?: number;
  isOfflineFallback?: boolean;
}
