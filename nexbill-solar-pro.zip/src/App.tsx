import React, { useState, useEffect } from 'react';
import {
  DocType,
  InvoiceItem,
  CustomerInfo,
  FirmInfo,
  BankInfo,
  TermsInfo,
  InvoiceMeta,
  WccDetails,
  QuotationDetails,
  StockItem,
  LicenseInfo
} from './types/solar';
import {
  DEFAULT_STOCKS,
  DEFAULT_FIRM,
  DEFAULT_BANK,
  DEFAULT_TERMS,
  DEFAULT_CUSTOMER
} from './data/defaultData';
import { licenseService, formatIntegerINR } from './services/licenseService';
import { HeaderNav } from './components/HeaderNav';
import { SidebarCalculator } from './components/SidebarCalculator';
import { CustomerDrawer } from './components/CustomerDrawer';
import { FirmSettingsDrawer } from './components/FirmSettingsDrawer';
import { DocumentViewer } from './components/DocumentViewer';
import { AdminPortalModal } from './components/AdminPortalModal';
import { PublicLandingModal } from './components/PublicLandingModal';
import { UpgradeModal } from './components/UpgradeModal';
import { UnlockModal } from './components/UnlockModal';

export default function App() {
  // License & Modals
  const [license, setLicense] = useState<LicenseInfo | null>(null);
  const [isLandingOpen, setIsLandingOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isUpgradeOpen, setIsUpgradeOpen] = useState(false);
  const [isUnlockOpen, setIsUnlockOpen] = useState(false);
  const [monthInvoiceCount, setMonthInvoiceCount] = useState(0);

  // App Layout State
  const [docType, setDocType] = useState<DocType>('invoice');
  const [templateStyle, setTemplateStyle] = useState<1 | 2 | 3>(1);
  const [activeSidebarTab, setActiveSidebarTab] = useState<'calc' | 'customer' | 'firm'>('calc');
  const [showBuyRates, setShowBuyRates] = useState(true);
  const [currency, setCurrency] = useState('₹');

  // Business Data
  const [targetPrice, setTargetPrice] = useState<number>(180000);
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [customer, setCustomer] = useState<CustomerInfo>(DEFAULT_CUSTOMER);
  const [firm, setFirm] = useState<FirmInfo>(DEFAULT_FIRM);
  const [bank, setBank] = useState<BankInfo>(DEFAULT_BANK);
  const [terms, setTerms] = useState<TermsInfo>(DEFAULT_TERMS);
  const [stockLibrary, setStockLibrary] = useState<StockItem[]>(DEFAULT_STOCKS);

  const [meta, setMeta] = useState<InvoiceMeta>({
    invNo: 'JE/26-27/001',
    date: new Date().toISOString().split('T')[0],
    eway: '',
    quotRef: 'QUOT/2026/041',
    placeOfSupply: 'Rajasthan (08)',
    reverseCharge: 'No',
    copyType: 'Original for Recipient',
  });

  const [wcc, setWcc] = useState<WccDetails>({
    plantCapacityKw: '3.00 kW',
    inverterMake: 'Polycab 3kW On-Grid (Deye / Growatt)',
    inverterSerial: 'PC-INV-2026-98124',
    panelMake: 'Waaree Bifacial DCR 550Wp ALMM',
    panelWattage: '550 Wp',
    panelCount: '6 NOS',
    completionDate: new Date().toISOString().split('T')[0],
    discomName: 'JVVNL / Jodhpur Discom',
  });

  const [quotation, setQuotation] = useState<QuotationDetails>({
    plantCapacityKw: '3 kW',
    annualGenerationUnits: 4380,
    annualSavingsRs: 35000,
    subsidyAmount: 78000,
    paybackYears: 2.8,
  });

  // -------------------------------------------------------------
  // Initialization & LocalStorage Persistence
  // -------------------------------------------------------------
  useEffect(() => {
    // 1. Load Month Invoices Count
    setMonthInvoiceCount(licenseService.getMonthInvoiceCount());

    // 2. Load Local Data
    try {
      const savedFirm = localStorage.getItem('nb_firm_data');
      if (savedFirm) setFirm(JSON.parse(savedFirm));

      const savedBank = localStorage.getItem('nb_bank_data');
      if (savedBank) setBank(JSON.parse(savedBank));

      const savedTerms = localStorage.getItem('nb_terms_data');
      if (savedTerms) setTerms(JSON.parse(savedTerms));

      const savedCustomer = localStorage.getItem('nb_customer_data');
      if (savedCustomer) setCustomer(JSON.parse(savedCustomer));

      const savedStocks = localStorage.getItem('nb_stocks_library');
      if (savedStocks) setStockLibrary(JSON.parse(savedStocks));

      const savedCurrency = localStorage.getItem('nb_currency');
      if (savedCurrency) setCurrency(savedCurrency);

      const savedItems = localStorage.getItem('nb_active_items');
      if (savedItems) {
        setItems(JSON.parse(savedItems));
      } else {
        // Initial Default 3kW Items
        loadDefaultItems();
      }
    } catch {
      loadDefaultItems();
    }

    // 3. Verify License Key
    checkInitialLicense();
  }, []);

  // Sync active items to local cache
  useEffect(() => {
    if (items.length > 0) {
      localStorage.setItem('nb_active_items', JSON.stringify(items));
    }
  }, [items]);

  // Periodic license re-check (checks if key was revoked by admin)
  useEffect(() => {
    const interval = setInterval(async () => {
      const key = license?.key;
      if (key) {
        const res = await licenseService.verifyKey(key);
        if (!res.valid) {
          setLicense(null);
          setIsLandingOpen(true);
          alert(res.message || 'License has been revoked or expired.');
        }
      }
    }, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [license]);

  const loadDefaultItems = () => {
    setItems([
      {
        id: 1,
        name: 'Solar PV Module DCR (ALMM Bifacial 550Wp)',
        hsn: '85414300',
        gst: 5,
        qty: 6,
        unit: 'NOS',
        buyRate: 11000,
        rate: 13500,
        serialNumbers: 'WAAREE-DCR-550W-01 to 06',
      },
      {
        id: 2,
        name: 'Solar Grid-Tied Inverter 3kW (Polycab / Deye)',
        hsn: '85044090',
        gst: 5,
        qty: 1,
        unit: 'Set',
        buyRate: 24000,
        rate: 32000,
        serialNumbers: 'PC-3KW-98124',
      },
      {
        id: 3,
        name: 'MMS GI C-Channel Structure (HDG 80 Micron)',
        hsn: '73089030',
        gst: 18,
        qty: 1,
        unit: 'Set',
        buyRate: 12000,
        rate: 17500,
      },
      {
        id: 4,
        name: 'DC Solar Cable 4 sq.mm Copper (Red & Black)',
        hsn: '85446020',
        gst: 18,
        qty: 60,
        unit: 'Mtr.',
        buyRate: 45,
        rate: 65,
      },
      {
        id: 5,
        name: 'ACDB & DCDB Distribution Box with SPD (IP65)',
        hsn: '85371000',
        gst: 18,
        qty: 1,
        unit: 'Set',
        buyRate: 5000,
        rate: 7200,
      },
      {
        id: 6,
        name: 'Chemical Earthing Kit + 2.25M GI Electrode',
        hsn: '83111000',
        gst: 18,
        qty: 2,
        unit: 'Set',
        buyRate: 3200,
        rate: 4800,
      },
      {
        id: 7,
        name: 'Turnkey Installation, Testing & Commissioning Charges',
        hsn: '9954',
        gst: 18,
        qty: 1,
        unit: 'Job',
        buyRate: 8000,
        rate: 12000,
      },
    ]);
  };

  const checkInitialLicense = async () => {
    const stored = licenseService.getStoredKey();
    if (stored) {
      const res = await licenseService.verifyKey(stored);
      if (res.valid && res.license) {
        setLicense(res.license);
        return;
      }
    }
    // No valid key found -> show public landing / pricing modal
    setIsLandingOpen(true);
  };

  const handleUnlockWithKey = async (key: string): Promise<{ success: boolean; message?: string }> => {
    const res = await licenseService.verifyKey(key);
    if (res.valid && res.license) {
      setLicense(res.license);
      setIsLandingOpen(false);
      setIsUnlockOpen(false);
      return { success: true };
    }
    return { success: false, message: res.message };
  };

  const handleTryTrial = async () => {
    await handleUnlockWithKey('TRIAL-NEXBILL-2026');
  };

  // Stock library handlers
  const handleAddStockItem = (newItem: StockItem) => {
    const updated = [newItem, ...stockLibrary.filter((s) => s.name !== newItem.name)];
    setStockLibrary(updated);
    localStorage.setItem('nb_stocks_library', JSON.stringify(updated));
  };

  const handleDeleteStockItem = (name: string) => {
    const updated = stockLibrary.filter((s) => s.name !== name);
    setStockLibrary(updated);
    localStorage.setItem('nb_stocks_library', JSON.stringify(updated));
  };

  // Save Settings handler
  const handleSaveFirmSettings = () => {
    localStorage.setItem('nb_firm_data', JSON.stringify(firm));
    localStorage.setItem('nb_bank_data', JSON.stringify(bank));
    localStorage.setItem('nb_terms_data', JSON.stringify(terms));
    localStorage.setItem('nb_currency', currency);
    alert('✅ Firm and bank details saved successfully!');
  };

  // Print Handler
  const handlePrint = async () => {
    // Check usage limits
    const check = licenseService.canGenerateInvoice(license);
    if (!check.allowed) {
      setIsUpgradeOpen(true);
      return;
    }

    // Record invoice generation
    const newCount = await licenseService.recordInvoiceGenerated(license?.key);
    setMonthInvoiceCount(newCount);

    // Trigger Print
    window.print();
  };

  // WhatsApp Share Handler
  const handleWhatsAppShare = () => {
    const totalAmount = items.reduce((acc, it) => {
      const line = (it.rate || 0) * (it.qty || 1);
      return acc + line * (1 + (it.gst || 0) / 100);
    }, 0);

    const text = encodeURIComponent(
      `*⚡ ${firm.name} — ${docType === 'invoice' ? 'Tax Invoice' : 'Solar Quotation'}*\n\n` +
      `👤 *Customer:* ${customer.name || 'Valued Customer'}\n` +
      `📄 *Doc No:* ${meta.invNo} | *Date:* ${meta.date}\n` +
      `☀️ *Plant:* ${wcc.plantCapacityKw}\n` +
      `💰 *Grand Total:* ${currency} ${formatIntegerINR(totalAmount)}\n\n` +
      `*Bank Details:*\n` +
      `Bank: ${bank.bankName}\n` +
      `A/C: ${bank.accountNo} | IFSC: ${bank.ifsc}\n` +
      (bank.upiId ? `UPI: ${bank.upiId}\n\n` : '\n') +
      `_Contact: ${firm.mobile}_\n` +
      `_PM Surya Ghar Muft Bijli Yojana Vendor_`
    );

    const phone = customer.mobile ? customer.mobile.replace(/[^0-9]/g, '') : '';
    const url = phone ? `https://wa.me/91${phone}?text=${text}` : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  return (
    <div className="flex h-screen w-screen flex-col bg-slate-950 font-sans antialiased text-slate-100 overflow-hidden">
      {/* Top Header Navigation */}
      <HeaderNav
        docType={docType}
        onDocTypeChange={setDocType}
        activeSidebarTab={activeSidebarTab}
        onSidebarTabChange={setActiveSidebarTab}
        templateStyle={templateStyle}
        onTemplateStyleChange={setTemplateStyle}
        showBuyRates={showBuyRates}
        onToggleBuyRates={() => setShowBuyRates(!showBuyRates)}
        license={license}
        monthInvoiceCount={monthInvoiceCount}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenLicenseChange={() => setIsUnlockOpen(true)}
        onPrint={handlePrint}
        onWhatsAppShare={handleWhatsAppShare}
      />

      {/* Main App Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar Drawer */}
        <aside className="w-80 sm:w-96 shrink-0 h-full overflow-hidden print:hidden">
          {activeSidebarTab === 'calc' && (
            <SidebarCalculator
              items={items}
              onItemsChange={setItems}
              targetPrice={targetPrice}
              onTargetPriceChange={setTargetPrice}
              stockLibrary={stockLibrary}
              onAddStockItem={handleAddStockItem}
              onDeleteStockItem={handleDeleteStockItem}
              currency={currency}
            />
          )}

          {activeSidebarTab === 'customer' && (
            <CustomerDrawer
              customer={customer}
              onCustomerChange={(c) => {
                setCustomer(c);
                localStorage.setItem('nb_customer_data', JSON.stringify(c));
              }}
            />
          )}

          {activeSidebarTab === 'firm' && (
            <FirmSettingsDrawer
              firm={firm}
              onFirmChange={setFirm}
              bank={bank}
              onBankChange={setBank}
              terms={terms}
              onTermsChange={setTerms}
              currency={currency}
              onCurrencyChange={setCurrency}
              license={license}
              onChangeLicense={() => setIsUnlockOpen(true)}
              onOpenAdmin={() => setIsAdminOpen(true)}
              onSaveAll={handleSaveFirmSettings}
            />
          )}
        </aside>

        {/* Center Canvas / Document Preview */}
        <main className="flex-1 overflow-y-auto bg-slate-900/60 p-4 sm:p-8 print:p-0 print:bg-white print:overflow-visible">
          <DocumentViewer
            docType={docType}
            templateStyle={templateStyle}
            showBuyRates={showBuyRates}
            currency={currency}
            items={items}
            onItemsChange={setItems}
            customer={customer}
            onCustomerChange={setCustomer}
            firm={firm}
            bank={bank}
            terms={terms}
            meta={meta}
            onMetaChange={setMeta}
            wcc={wcc}
            onWccChange={setWcc}
            quotation={quotation}
            onQuotationChange={setQuotation}
            stockLibrary={stockLibrary}
          />
        </main>
      </div>

      {/* Public Sales / Landing Modal */}
      <PublicLandingModal
        isOpen={isLandingOpen}
        onUnlockWithKey={handleUnlockWithKey}
        onTryTrial={handleTryTrial}
        onOpenAdmin={() => {
          setIsLandingOpen(false);
          setIsAdminOpen(true);
        }}
      />

      {/* Owner / Admin License Manager Modal */}
      <AdminPortalModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        onLicenseChanged={checkInitialLicense}
      />

      {/* Upgrade Modal (Shown when trial limits hit) */}
      <UpgradeModal
        isOpen={isUpgradeOpen}
        onClose={() => setIsUpgradeOpen(false)}
        onEnterKey={() => setIsUnlockOpen(true)}
      />

      {/* Change / Re-enter License Key Modal */}
      <UnlockModal
        isOpen={isUnlockOpen}
        onClose={() => setIsUnlockOpen(false)}
        onVerifyKey={handleUnlockWithKey}
      />
    </div>
  );
}
