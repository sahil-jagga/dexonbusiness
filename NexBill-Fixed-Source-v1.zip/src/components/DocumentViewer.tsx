import React from 'react';
import {
  DocType,
  InvoiceItem,
  CustomerInfo,
  FirmInfo,
  BankInfo,
  TermsInfo,
  InvoiceMeta,
  WccDetails,
  QuotationDetails,
  MarginReceiptDetails,
  StockItem,
  TradeKey,
} from '../types/solar';
import { formatINR, formatIntegerINR, numberToWordsRupees } from '../services/licenseService';
import { maskAadhaar } from '../utils/privacy';
import { t, Language } from '../utils/i18n';
import { Trash2, Plus, Sun, ShieldCheck, ChevronUp, ChevronDown, GripVertical, CheckCircle2, Receipt, Search } from 'lucide-react';

interface DocumentViewerProps {
  docType: DocType;
  templateStyle: 1 | 2 | 3; // 1: Clean, 2: Blue, 3: Dark
  showBuyRates: boolean;
  currency: string;
  items: InvoiceItem[];
  onItemsChange: (items: InvoiceItem[]) => void;
  customer: CustomerInfo;
  onCustomerChange: (c: CustomerInfo) => void;
  firm: FirmInfo;
  bank: BankInfo;
  terms: TermsInfo;
  meta: InvoiceMeta;
  onMetaChange: (m: InvoiceMeta) => void;
  wcc: WccDetails;
  onWccChange: (w: WccDetails) => void;
  quotation: QuotationDetails;
  onQuotationChange: (q: QuotationDetails) => void;
  marginReceipt?: MarginReceiptDetails;
  onMarginReceiptChange?: (m: MarginReceiptDetails) => void;
  stockLibrary: StockItem[];
  accentColor?: string;
  watermarkText?: string;
  trade?: TradeKey;
  lang?: Language;
}

export const DocumentViewer: React.FC<DocumentViewerProps> = ({
  docType,
  templateStyle,
  showBuyRates,
  currency,
  items,
  onItemsChange,
  customer,
  onCustomerChange,
  firm,
  bank,
  terms,
  meta,
  onMetaChange,
  wcc,
  onWccChange,
  quotation,
  onQuotationChange,
  marginReceipt,
  onMarginReceiptChange,
  stockLibrary,
  accentColor,
  watermarkText,
  trade = 'solar',
  lang = 'en',
}) => {
  // Autocomplete suggestion state
  const [activeSuggestId, setActiveSuggestId] = React.useState<number | null>(null);
  // Calculations
  let totalTaxable = 0;
  let totalCgst = 0;
  let totalSgst = 0;

  const calculatedItems = items.map((it) => {
    const qty = Number(it.qty) || 0;
    const rate = Number(it.rate) || 0;
    const gst = Number(it.gst) || 0;
    const lineTotal = qty * rate;
    const cgst = (lineTotal * (gst / 2)) / 100;
    const sgst = (lineTotal * (gst / 2)) / 100;
    const totalWithTax = lineTotal + cgst + sgst;

    totalTaxable += lineTotal;
    totalCgst += cgst;
    totalSgst += sgst;

    return {
      ...it,
      lineTotal,
      cgst,
      sgst,
      totalWithTax,
    };
  });

  const rawGrandTotal = totalTaxable + totalCgst + totalSgst;
  const grandTotal = Math.round(rawGrandTotal);
  const roundOff = grandTotal - rawGrandTotal;

  // HSN Breakdown
  const hsnBuckets: { [rate: number]: { taxable: number; cgst: number; sgst: number } } = {};
  calculatedItems.forEach((it) => {
    const r = it.gst || 0;
    if (!hsnBuckets[r]) hsnBuckets[r] = { taxable: 0, cgst: 0, sgst: 0 };
    hsnBuckets[r].taxable += it.lineTotal;
    hsnBuckets[r].cgst += it.cgst;
    hsnBuckets[r].sgst += it.sgst;
  });

  // Handlers for Items
  const handleItemChange = (id: number, field: keyof InvoiceItem, val: any) => {
    const updated = items.map((it) => {
      if (it.id !== id) return it;
      const copy: any = { ...it, [field]: val };
      // Auto-fill HSN and GST if item name matches stock
      if (field === 'name') {
        const found = stockLibrary.find((s) => s.name === val);
        if (found) {
          copy.hsn = found.hsn;
          copy.gst = found.gst;
          if (found.defaultBuy && !copy.buyRate) {
            copy.buyRate = found.defaultBuy;
          }
        }
      }
      return copy;
    });
    onItemsChange(updated);
  };

  const handleSelectStockSuggestion = (id: number, s: StockItem) => {
    const updated = items.map((it) => {
      if (it.id !== id) return it;
      const buyRate = s.defaultBuy || it.buyRate || 0;
      const rate = it.rate && it.rate > 0 ? it.rate : (buyRate > 0 ? Math.round(buyRate * 1.25) : 1000);
      return {
        ...it,
        name: s.name,
        hsn: s.hsn,
        gst: s.gst,
        buyRate: buyRate || it.buyRate,
        rate: rate,
      };
    });
    onItemsChange(updated);
    setActiveSuggestId(null);
  };

  const handleAddItemRow = () => {
    const newItem: InvoiceItem = {
      id: Date.now(),
      name: '',
      hsn: '85414300',
      gst: 18,
      qty: 1,
      unit: 'NOS',
      buyRate: 1000,
      rate: 1300,
      serialNumbers: '',
    };
    onItemsChange([...items, newItem]);
  };

  const handleDeleteItemRow = (id: number) => {
    onItemsChange(items.filter((it) => it.id !== id));
  };

  // Reorder Item Controls (Move Up, Move Down, Drag & Drop)
  const [draggedIdx, setDraggedIdx] = React.useState<number | null>(null);

  const handleMoveItemUp = (index: number) => {
    if (index <= 0) return;
    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[index - 1];
    newItems[index - 1] = temp;
    onItemsChange(newItems);
  };

  const handleMoveItemDown = (index: number) => {
    if (index >= items.length - 1) return;
    const newItems = [...items];
    const temp = newItems[index];
    newItems[index] = newItems[index + 1];
    newItems[index + 1] = temp;
    onItemsChange(newItems);
  };

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIdx(index);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (targetIndex: number) => {
    if (draggedIdx === null || draggedIdx === targetIndex) return;
    const newItems = [...items];
    const [moved] = newItems.splice(draggedIdx, 1);
    newItems.splice(targetIndex, 0, moved);
    setDraggedIdx(null);
    onItemsChange(newItems);
  };

  // Firm Header Component
  const renderFirmHeader = (theme: 1 | 2 | 3) => {
    const nameColor =
      theme === 1 ? 'text-slate-900' : theme === 2 ? 'text-white' : 'text-amber-400';
    const subColor =
      theme === 1 ? 'text-slate-600' : theme === 2 ? 'text-blue-100' : 'text-slate-300';

    return (
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3.5">
          {firm.logo ? (
            <img
              src={firm.logo}
              alt="Logo"
              className="h-16 w-28 object-contain rounded bg-white/10 p-1"
            />
          ) : (
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-amber-500 text-slate-950 shadow-md">
              <Sun className="h-8 w-8" />
            </div>
          )}
          <div>
            <h1 className={`text-xl font-black tracking-tight ${nameColor} leading-tight`}>
              {firm.name}
            </h1>
            <p className={`text-[10px] font-semibold ${subColor} mt-0.5`}>
              {firm.tagline || 'Solar Energy Solutions | PM Surya Ghar Empanelled Vendor'}
            </p>
            <p className={`text-[10px] ${subColor} leading-relaxed`}>{firm.address}</p>
            <p className={`text-[10px] ${subColor}`}>
              <b>Tel:</b> {firm.mobile} | <b>GSTIN:</b> {firm.gstin} {firm.pan ? `| PAN: ${firm.pan}` : ''}
              {firm.email ? ` | ${firm.email}` : ''}
            </p>
          </div>
        </div>

        <div className="text-right shrink-0">
          <div
            className={`inline-block rounded-lg px-3 py-1 text-xs font-black uppercase tracking-wider ${
              theme === 1
                ? 'bg-slate-900 text-amber-400'
                : theme === 2
                ? 'bg-white/20 text-white border border-white/30 backdrop-blur'
                : 'bg-amber-400 text-slate-950'
            }`}
          >
            {docType === 'invoice'
              ? 'TAX INVOICE'
              : docType === 'quotation'
              ? 'SOLAR QUOTATION'
              : docType === 'wcc'
              ? 'WORK COMPLETION'
              : 'BANK LOAN ESTIMATE'}
          </div>
          <div className={`mt-1 text-[10px] font-semibold ${subColor}`}>
            {meta.copyType || 'Original for Recipient'}
          </div>
        </div>
      </div>
    );
  };

  // Watermark Render
  const renderWatermark = () => {
    if (!watermarkText) return null;
    return (
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-[0.07] select-none z-0 overflow-hidden">
        <span className="text-6xl sm:text-8xl font-black uppercase tracking-widest rotate-[-30deg] text-slate-950 border-4 border-slate-950 px-8 py-3 rounded-3xl">
          {watermarkText}
        </span>
      </div>
    );
  };

  // Meta Information Bar
  const renderMetaRow = (bgClass: string, textClass: string) => {
    return (
      <div className={`mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg ${bgClass} px-3 py-2 text-[10px] ${textClass}`}>
        <div>
          <b>Doc No:</b>{' '}
          <input
            type="text"
            value={meta.invNo}
            onChange={(e) => onMetaChange({ ...meta, invNo: e.target.value })}
            placeholder="JE/26-27/001"
            className="border-b border-dashed border-current bg-transparent font-bold focus:outline-none"
          />
        </div>
        <div>
          <b>Date:</b>{' '}
          <input
            type="date"
            value={meta.date}
            onChange={(e) => onMetaChange({ ...meta, date: e.target.value })}
            className="border-b border-dashed border-current bg-transparent font-bold focus:outline-none"
          />
        </div>
        <div>
          <b>E-Way Bill:</b>{' '}
          <input
            type="text"
            value={meta.eway}
            onChange={(e) => onMetaChange({ ...meta, eway: e.target.value })}
            placeholder="Optional"
            className="border-b border-dashed border-current bg-transparent focus:outline-none w-24"
          />
        </div>
        <div>
          <b>Place of Supply:</b> {meta.placeOfSupply || 'Rajasthan (08)'}
        </div>
        <div>
          <b>Reverse Charge:</b> {meta.reverseCharge || 'No'}
        </div>
      </div>
    );
  };

  // Customer Billed / Shipped Box
  const renderCustomerBoxes = (borderClass: string, headerClass: string) => {
    return (
      <div className="mt-3 grid grid-cols-2 gap-3 text-[10px]">
        <div className={`rounded-lg border ${borderClass} p-2.5`}>
          <div className={`font-bold uppercase tracking-wider mb-1 ${headerClass}`}>
            Billed To (Site Owner)
          </div>
          <div className="space-y-0.5 leading-relaxed">
            <div className="font-bold text-xs">{customer.name || '—'}</div>
            {customer.relation && <div>{customer.relation}</div>}
            <div className="whitespace-pre-line">{customer.address || '—'}</div>
            {customer.mobile && <div><b>Mobile:</b> {customer.mobile}</div>}
            {customer.aadhar && <div><b>Aadhaar:</b> {maskAadhaar(customer.aadhar)}</div>}
            {customer.appNo && <div className="text-amber-600 font-semibold"><b>App No (Surya Ghar):</b> {customer.appNo}</div>}
            {customer.consumerNo && <div><b>K-No / Consumer No:</b> {customer.consumerNo}</div>}
            {customer.gstin && <div><b>GSTIN:</b> {customer.gstin}</div>}
          </div>
        </div>

        <div className={`rounded-lg border ${borderClass} p-2.5`}>
          <div className={`font-bold uppercase tracking-wider mb-1 ${headerClass}`}>
            Shipped To (Installation Site)
          </div>
          <div className="space-y-0.5 leading-relaxed">
            <div className="font-bold text-xs">{customer.name || '—'}</div>
            <div className="whitespace-pre-line">{customer.address || 'Same as Billing Address'}</div>
            {customer.sanctionLoad && <div><b>Sanctioned Load:</b> {customer.sanctionLoad}</div>}
            {customer.mobile && <div><b>Contact:</b> {customer.mobile}</div>}
            <div className="text-slate-500 italic mt-1">Solar Rooftop On-Grid Net-Metered Site</div>
          </div>
        </div>
      </div>
    );
  };

  // Main Items Table
  const renderItemsTable = (thClass: string, totalRowClass: string) => {
    return (
      <div className="mt-3 overflow-x-auto">
        {/* Datalist for fast item stock selection */}
        <datalist id="stock-datalist">
          {stockLibrary.map((s) => (
            <option key={s.name} value={s.name} />
          ))}
        </datalist>

        <table className="w-full border-collapse text-[10px]">
          <thead>
            <tr className={thClass}>
              <th className="py-2 px-1 text-center w-12 print:w-6">#</th>
              <th className="py-2 px-2 text-left">Description of Goods / Services</th>
              <th className="py-2 px-1.5 text-center w-16">HSN/SAC</th>
              <th className="py-2 px-1 text-center w-12">GST%</th>
              <th className="py-2 px-1 text-center w-12">Qty</th>
              <th className="py-2 px-1 text-center w-12">Unit</th>
              {showBuyRates && (
                <th className="py-2 px-1 text-right w-16 bg-amber-900/20 text-amber-300">
                  Buy Rate
                </th>
              )}
              <th className="py-2 px-1.5 text-right w-18">Rate ({currency})</th>
              <th className="py-2 px-1.5 text-right w-16">CGST</th>
              <th className="py-2 px-1.5 text-right w-16">SGST</th>
              <th className="py-2 px-2 text-right w-20">Total ({currency})</th>
              <th className="py-2 px-1 w-6 print:hidden"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {calculatedItems.map((it, idx) => (
              <tr
                key={it.id}
                onDragOver={handleDragOver}
                onDrop={() => handleDrop(idx)}
                className={`hover:bg-slate-50/50 transition-colors ${
                  draggedIdx === idx ? 'opacity-40 bg-amber-50 border-y-2 border-dashed border-amber-400' : ''
                }`}
              >
                <td className="py-2 px-1 text-center text-slate-400 font-medium align-middle">
                  {/* Clean number on Print / PDF */}
                  <span className="hidden print:inline">{idx + 1}</span>

                  {/* Interactive Drag & Up/Down Controls in Editor */}
                  <div className="flex items-center justify-center gap-0.5 print:hidden">
                    <div
                      draggable
                      onDragStart={(e) => handleDragStart(e, idx)}
                      title="Drag to reorder"
                      className="cursor-grab active:cursor-grabbing text-slate-400 hover:text-slate-700 p-0.5"
                    >
                      <GripVertical className="h-3.5 w-3.5" />
                    </div>
                    <span className="font-bold text-slate-700 text-[11px] w-3 text-center">{idx + 1}</span>
                    <div className="flex flex-col -space-y-1 ml-0.5">
                      <button
                        type="button"
                        title="Move Up"
                        disabled={idx === 0}
                        onClick={() => handleMoveItemUp(idx)}
                        className="p-0.5 text-slate-400 hover:text-amber-600 disabled:opacity-20 disabled:hover:text-slate-400"
                      >
                        <ChevronUp className="h-3 w-3" />
                      </button>
                      <button
                        type="button"
                        title="Move Down"
                        disabled={idx === calculatedItems.length - 1}
                        onClick={() => handleMoveItemDown(idx)}
                        className="p-0.5 text-slate-400 hover:text-amber-600 disabled:opacity-20 disabled:hover:text-slate-400"
                      >
                        <ChevronDown className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                </td>
                <td className="py-2 px-2 text-left">
                  {/* Editor Mode with Interactive Catalog Autocomplete */}
                  <div className="print:hidden space-y-1">
                    <div className="relative">
                      <textarea
                        rows={Math.max(1, Math.min(4, Math.ceil((it.name?.length || 0) / 30)))}
                        value={it.name}
                        placeholder="Enter item description or type to search catalog..."
                        onFocus={() => setActiveSuggestId(it.id)}
                        onBlur={() => setTimeout(() => setActiveSuggestId(null), 250)}
                        onChange={(e) => {
                          handleItemChange(it.id, 'name', e.target.value);
                          setActiveSuggestId(it.id);
                        }}
                        className="w-full bg-transparent font-semibold text-slate-900 focus:outline-none resize-none leading-snug text-xs py-0.5"
                      />
                      {activeSuggestId === it.id && it.name && it.name.trim().length > 0 && (
                        <div className="absolute left-0 top-full z-50 mt-0.5 w-80 max-h-52 overflow-y-auto rounded-xl border border-amber-500/40 bg-slate-950 p-1.5 shadow-2xl text-left">
                          <div className="px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-amber-400 border-b border-slate-800 flex justify-between items-center">
                            <span>📦 Catalog Suggestions</span>
                            <span className="text-slate-500 text-[8px]">Click to auto-fill</span>
                          </div>
                          {stockLibrary
                            .filter((s) => s.name.toLowerCase().includes(it.name.toLowerCase()))
                            .slice(0, 6)
                            .map((s) => (
                              <button
                                key={s.name}
                                type="button"
                                onMouseDown={(e) => {
                                  e.preventDefault();
                                  handleSelectStockSuggestion(it.id, s);
                                }}
                                className="w-full text-left rounded-lg p-2 text-[10px] hover:bg-amber-500/20 text-slate-200 hover:text-white transition group border border-transparent hover:border-amber-500/30 my-0.5"
                              >
                                <div className="font-bold text-amber-300 group-hover:text-amber-200 leading-snug">{s.name}</div>
                                <div className="flex gap-2 text-[9px] text-slate-400 mt-0.5">
                                  <span>HSN: <b className="text-slate-300">{s.hsn}</b></span>
                                  <span>GST: <b className="text-slate-300">{s.gst}%</b></span>
                                  {s.defaultBuy && <span>Cost: <b className="text-emerald-400">₹{s.defaultBuy}</b></span>}
                                </div>
                              </button>
                            ))}
                        </div>
                      )}
                    </div>
                    <textarea
                      rows={Math.max(1, Math.min(5, Math.ceil((it.serialNumbers?.length || 0) / 40)))}
                      value={it.serialNumbers || ''}
                      placeholder="Serial no. / Make / Extra notes (auto expands)..."
                      onChange={(e) => handleItemChange(it.id, 'serialNumbers', e.target.value)}
                      className="w-full bg-slate-50/80 rounded border border-slate-200 px-1.5 py-0.5 text-[10px] text-slate-700 font-mono focus:border-amber-500 focus:bg-white focus:outline-none resize-y min-h-[24px] leading-relaxed"
                    />
                  </div>

                  {/* Clean Print Mode - Full Text Wrapping, No Truncation */}
                  <div className="hidden print:block">
                    <div className="font-bold text-slate-900 leading-snug whitespace-pre-wrap break-words text-[11px]">
                      {it.name || '—'}
                    </div>
                    {it.serialNumbers && (
                      <div className="text-[9.5px] text-slate-700 font-mono mt-1 whitespace-pre-wrap break-words leading-relaxed border-l-2 border-slate-300 pl-1.5">
                        {it.serialNumbers}
                      </div>
                    )}
                  </div>
                </td>

                <td className="py-2 px-1.5 text-center">
                  <div className="print:hidden">
                    <input
                      type="text"
                      value={it.hsn}
                      onChange={(e) => handleItemChange(it.id, 'hsn', e.target.value)}
                      className="w-full text-center bg-transparent focus:outline-none font-mono"
                    />
                  </div>
                  <span className="hidden print:inline font-mono">{it.hsn}</span>
                </td>

                <td className="py-2 px-1 text-center">
                  {/* Editor Mode Select */}
                  <div className="print:hidden">
                    <select
                      value={it.gst}
                      onChange={(e) => handleItemChange(it.id, 'gst', Number(e.target.value))}
                      className="bg-transparent text-center font-bold focus:outline-none cursor-pointer"
                    >
                      <option value={5}>5%</option>
                      <option value={18}>18%</option>
                      <option value={12}>12%</option>
                      <option value={0}>0%</option>
                    </select>
                  </div>
                  {/* Print Mode - Clean text without dropdown arrow */}
                  <span className="hidden print:inline font-bold">{it.gst}%</span>
                </td>

                <td className="py-2 px-1 text-center">
                  <div className="print:hidden">
                    <input
                      type="number"
                      value={it.qty || ''}
                      onChange={(e) => handleItemChange(it.id, 'qty', Number(e.target.value))}
                      className="w-full text-center bg-transparent font-bold focus:outline-none"
                    />
                  </div>
                  <span className="hidden print:inline font-bold">{it.qty}</span>
                </td>

                <td className="py-2 px-1 text-center">
                  {/* Editor Mode Select */}
                  <div className="print:hidden">
                    <select
                      value={it.unit}
                      onChange={(e) => handleItemChange(it.id, 'unit', e.target.value)}
                      className="bg-transparent text-center focus:outline-none cursor-pointer"
                    >
                      <option value="NOS">NOS</option>
                      <option value="Pcs.">Pcs.</option>
                      <option value="Set">Set</option>
                      <option value="Mtr.">Mtr.</option>
                      <option value="Kg.">Kg.</option>
                      <option value="Job">Job</option>
                    </select>
                  </div>
                  {/* Print Mode - Clean text without dropdown arrow */}
                  <span className="hidden print:inline">{it.unit}</span>
                </td>

                {showBuyRates && (
                  <td className="py-2 px-1 text-right bg-amber-50/50">
                    <input
                      type="number"
                      value={it.buyRate || ''}
                      onChange={(e) => handleItemChange(it.id, 'buyRate', Number(e.target.value))}
                      className="w-full text-right bg-transparent text-amber-800 font-bold focus:outline-none"
                    />
                  </td>
                )}

                <td className="py-2 px-1.5 text-right font-medium">
                  <div className="print:hidden">
                    <input
                      type="number"
                      value={it.rate || ''}
                      onChange={(e) => handleItemChange(it.id, 'rate', Number(e.target.value))}
                      className="w-full text-right bg-transparent font-bold focus:outline-none"
                    />
                  </div>
                  <span className="hidden print:inline font-medium">{formatINR(it.rate)}</span>
                </td>

                <td className="py-2 px-1.5 text-right text-emerald-700 font-medium">
                  {formatINR(it.cgst)}
                </td>
                <td className="py-2 px-1.5 text-right text-emerald-700 font-medium">
                  {formatINR(it.sgst)}
                </td>
                <td className="py-2 px-2 text-right font-extrabold text-slate-900">
                  {formatINR(it.totalWithTax)}
                </td>
                <td className="py-2 px-1 text-center print:hidden">
                  <button
                    onClick={() => handleDeleteItemRow(it.id)}
                    className="text-slate-400 hover:text-rose-500 p-0.5"
                    title="Delete row"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t-2 border-slate-300 font-bold bg-slate-50">
              <td colSpan={showBuyRates ? 7 : 6} className="py-1.5 px-2 text-right">
                Taxable Subtotal:
              </td>
              <td className="py-1.5 px-1.5 text-right">{formatINR(totalTaxable)}</td>
              <td className="py-1.5 px-1.5 text-right text-emerald-700">{formatINR(totalCgst)}</td>
              <td className="py-1.5 px-1.5 text-right text-emerald-700">{formatINR(totalSgst)}</td>
              <td className="py-1.5 px-2 text-right font-extrabold">{formatINR(rawGrandTotal)}</td>
              <td className="print:hidden"></td>
            </tr>

            {roundOff !== 0 && (
              <tr className="text-[9px] text-slate-500">
                <td colSpan={showBuyRates ? 9 : 8} className="py-0.5 px-2 text-right">
                  Round Off (+/-):
                </td>
                <td colSpan={2} className="py-0.5 px-2 text-right font-mono">
                  {roundOff > 0 ? `+${roundOff.toFixed(2)}` : roundOff.toFixed(2)}
                </td>
                <td className="print:hidden"></td>
              </tr>
            )}

            <tr className={totalRowClass}>
              <td colSpan={showBuyRates ? 6 : 5} className="py-2.5 px-3 text-left font-normal text-[10px]">
                <div className="font-semibold text-slate-700">Amount in Words:</div>
                <div className="font-bold italic text-slate-900 mt-0.5">
                  {numberToWordsRupees(grandTotal)}
                </div>
              </td>
              <td colSpan={2} className="py-2.5 px-2 text-right uppercase tracking-wider text-xs">
                Grand Total ({currency}):
              </td>
              <td colSpan={3} className="py-2.5 px-3 text-right font-black text-base">
                {currency} {formatIntegerINR(grandTotal)}
              </td>
              <td className="print:hidden"></td>
            </tr>
          </tfoot>
        </table>

        {/* Add Row Button in Table */}
        <div className="mt-2 flex justify-start print:hidden">
          <button
            onClick={handleAddItemRow}
            className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 shadow-sm"
          >
            <Plus className="h-3.5 w-3.5 text-emerald-600" /> + Add Row
          </button>
        </div>
      </div>
    );
  };

  // Tax Summary / GST Slab Breakdown Table (For Accounting & ITR Clarity)
  const renderGstBreakdown = (thClass: string) => {
    const sortedEntries = Object.entries(hsnBuckets).sort((a, b) => Number(a[0]) - Number(b[0]));

    return (
      <div className="mt-3 flex flex-col sm:flex-row items-stretch sm:items-start justify-between gap-3">
        {/* Left: Tax Accounting Note */}
        <div className="flex-1 text-[9.5px] text-slate-600 bg-slate-50/80 rounded-lg p-2.5 border border-slate-200">
          <div className="font-bold text-slate-800 uppercase tracking-wider text-[9px] mb-0.5">
            Tax Accounting Summary & Reverse Charge Note
          </div>
          <p className="leading-relaxed">
            {trade === 'solar'
              ? 'GST calculated under CGST & SGST Rules 2017 & CBIC Notification No. 8/2021-CT(R) for Solar EPC Composite Supply (70% goods + 30% services) or applicable statutory HSN/SAC classifications.'
              : 'GST tax calculated in accordance with statutory CGST & SGST Rules 2017 based on respective HSN/SAC classifications.'}
          </p>
        </div>

        {/* Right: Structured Tax Summary Table */}
        <div className="shrink-0 overflow-x-auto">
          <table className="border-collapse text-[9px] min-w-[340px] border border-slate-300 rounded-lg overflow-hidden shadow-xs">
            <thead>
              <tr className={thClass}>
                <th colSpan={5} className="py-1 px-2.5 text-left uppercase tracking-wider font-extrabold text-[9px] border-b border-white/20">
                  Tax Summary (Slab-wise Breakdown)
                </th>
              </tr>
              <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                <th className="py-1 px-2 text-center">Tax Slab</th>
                <th className="py-1 px-2 text-right">Taxable ({currency})</th>
                <th className="py-1 px-2 text-right">CGST (Rate/Amt)</th>
                <th className="py-1 px-2 text-right">SGST (Rate/Amt)</th>
                <th className="py-1 px-2 text-right">Total Tax ({currency})</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 bg-white">
              {sortedEntries.length > 0 ? (
                sortedEntries.map(([rateStr, vals]) => {
                  const rate = Number(rateStr);
                  const halfRate = (rate / 2).toFixed(1).replace('.0', '');
                  return (
                    <tr key={rateStr} className="hover:bg-slate-50">
                      <td className="py-1 px-2 text-center font-bold text-slate-900">
                        {rate}% GST
                      </td>
                      <td className="py-1 px-2 text-right font-medium">{formatINR(vals.taxable)}</td>
                      <td className="py-1 px-2 text-right text-emerald-800">
                        <span className="text-[8px] text-slate-400 mr-1">({halfRate}%)</span>
                        {formatINR(vals.cgst)}
                      </td>
                      <td className="py-1 px-2 text-right text-emerald-800">
                        <span className="text-[8px] text-slate-400 mr-1">({halfRate}%)</span>
                        {formatINR(vals.sgst)}
                      </td>
                      <td className="py-1 px-2 text-right font-bold text-slate-950">
                        {formatINR(vals.cgst + vals.sgst)}
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={5} className="py-1 px-2 text-center text-slate-400 italic">
                    No taxable items
                  </td>
                </tr>
              )}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-slate-300 font-black bg-slate-100 text-slate-950">
                <td className="py-1.5 px-2 text-center uppercase tracking-wide">Total</td>
                <td className="py-1.5 px-2 text-right">{formatINR(totalTaxable)}</td>
                <td className="py-1.5 px-2 text-right text-emerald-800">{formatINR(totalCgst)}</td>
                <td className="py-1.5 px-2 text-right text-emerald-800">{formatINR(totalSgst)}</td>
                <td className="py-1.5 px-2 text-right font-black text-slate-950">
                  {formatINR(totalCgst + totalSgst)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    );
  };

  // Bank & Footer Signatures
  const renderFooter = (bankBgClass: string, sigColor: string) => {
    return (
      <div className="mt-4 pt-3 border-t border-slate-300 text-[10px]">
        {/* Bank Bar */}
        <div className={`rounded-lg ${bankBgClass} p-2 flex flex-wrap items-center justify-between gap-2`}>
          <div>
            <b>Bank Details:</b> {bank.bankName} | <b>A/C No:</b> {bank.accountNo} | <b>IFSC:</b>{' '}
            {bank.ifsc} | <b>Branch:</b> {bank.branch}
          </div>
          {bank.upiId && (
            <div className="font-semibold text-emerald-700">
              <b>UPI / QR:</b> {bank.upiId}
            </div>
          )}
        </div>

        {/* Declaration & T&C */}
        <div className="mt-2 space-y-1 text-[9px] text-slate-600">
          <div>
            <b>Declaration:</b> {terms.declaration}
          </div>
          <div>
            <b>Terms & Conditions:</b> {terms.tnc}
          </div>
        </div>

        {/* Signatures */}
        <div className="mt-8 flex items-end justify-between pt-4">
          <div className="text-center">
            <div className={`w-40 border-t ${sigColor} mb-1`} />
            <div className="font-semibold text-slate-700">Customer / Receiver Signature</div>
          </div>

          <div className="text-center flex flex-col items-center">
            <div className="text-xs font-bold text-slate-900">For {firm.name}</div>
            {firm.signature ? (
              <div className="h-12 flex items-center justify-center my-1">
                <img
                  src={firm.signature}
                  alt="Authorised Signatory"
                  className="max-h-12 max-w-[160px] object-contain"
                />
              </div>
            ) : (
              <div className="h-8" />
            )}
            <div className={`w-48 border-t ${sigColor} mb-1`} />
            <div className="font-semibold text-slate-700">Authorised Signatory</div>
          </div>
        </div>
      </div>
    );
  };

  // -------------------------------------------------------------
  // Render: WCC (Work Completion Certificate) - Solar Exclusive
  // -------------------------------------------------------------
  if (docType === 'wcc') {
    if (trade !== 'solar') {
      return (
        <div className="mx-auto w-full max-w-2xl bg-white text-slate-900 p-8 shadow-xl rounded-xl text-center">
          <div className="rounded-xl border border-amber-300 bg-amber-50 p-6">
            <h3 className="text-base font-bold text-amber-900">
              Document Not Applicable for {trade.replace('_', ' ').toUpperCase()}
            </h3>
            <p className="mt-2 text-xs text-amber-700">
              Work Completion Certificate (WCC) is statutory for Solar EPC & Rooftop installations.
              Please switch to <b>Tax Invoice</b> or <b>Quotation</b> for your active trade.
            </p>
          </div>
        </div>
      );
    }

    return (
      <div className="mx-auto w-full max-w-4xl bg-white text-slate-900 p-8 sm:p-12 shadow-2xl rounded-xl print:shadow-none print:p-0">
        {/* WCC Header */}
        <div className="border-b-2 border-slate-900 pb-4 text-center">
          <h1 className="text-2xl font-black text-slate-900 uppercase tracking-tight">
            {firm.name}
          </h1>
          <p className="text-xs text-slate-600 font-medium mt-1">
            {firm.tagline || 'Solar Energy Solutions | PM Surya Ghar: Muft Bijli Yojana Vendor'}
          </p>
          <p className="text-xs text-slate-600">{firm.address}</p>
          <p className="text-xs text-slate-600">
            GSTIN: <b>{firm.gstin}</b> | Phone: <b>{firm.mobile}</b>
          </p>
        </div>

        {/* Title */}
        <div className="mt-6 text-center">
          <span className="inline-block border-b-2 border-slate-900 pb-1 text-base font-extrabold uppercase tracking-wider text-slate-900">
            Work Completion Certificate (WCC)
          </span>
          <p className="mt-1 text-xs text-slate-500">
            As per Ministry of New & Renewable Energy (MNRE) & PM Surya Ghar Guidelines
          </p>
        </div>

        <p className="mt-6 text-xs text-slate-700 leading-relaxed">
          This is to solemnly certify that <b>{firm.name}</b> (GSTIN: {firm.gstin}), having its office at {firm.address}, has successfully supplied, erected, tested, and commissioned the Grid-Connected Solar Rooftop Power Plant as per the following specifications:
        </p>

        {/* Detailed Table Grid */}
        <div className="mt-6 divide-y divide-slate-200 border border-slate-300 rounded-lg text-xs">
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">1. EPC Vendor / Installer:</div>
            <div className="flex-1 font-semibold">{firm.name}</div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">2. Beneficiary / Site Owner:</div>
            <div className="flex-1 font-semibold">{customer.name || '—'} {customer.relation ? `(${customer.relation})` : ''}</div>
          </div>
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">3. Installation Site Address:</div>
            <div className="flex-1 whitespace-pre-line">{customer.address || '—'}</div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">4. Solar Plant Capacity:</div>
            <div className="flex-1 font-bold text-emerald-800 flex items-center gap-1">
              <input
                type="text"
                value={wcc.plantCapacityKw}
                onChange={(e) => onWccChange({ ...wcc, plantCapacityKw: e.target.value })}
                placeholder="e.g. 3.00 kW"
                className="border-b border-dashed border-current bg-transparent focus:outline-none w-32 font-bold"
              />
              <span>(On-Grid Rooftop)</span>
            </div>
          </div>
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">5. Solar PV Module Make & Type:</div>
            <div className="flex-1 flex gap-2">
              <input
                type="text"
                value={wcc.panelMake}
                onChange={(e) => onWccChange({ ...wcc, panelMake: e.target.value })}
                placeholder="e.g. Waaree Bifacial DCR 550Wp"
                className="w-full border-b border-dashed border-current bg-transparent focus:outline-none font-semibold"
              />
            </div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">6. Solar Inverter Make & Serial:</div>
            <div className="flex-1 flex gap-2">
              <input
                type="text"
                value={wcc.inverterMake}
                onChange={(e) => onWccChange({ ...wcc, inverterMake: e.target.value })}
                placeholder="e.g. Polycab 3kW / Deye String Inverter"
                className="w-full border-b border-dashed border-current bg-transparent focus:outline-none font-semibold"
              />
            </div>
          </div>
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">7. Electricity Consumer K-No.:</div>
            <div className="flex-1 font-mono font-semibold">{customer.consumerNo || '—'}</div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">8. PM Surya Ghar App No.:</div>
            <div className="flex-1 font-mono font-bold text-amber-700">{customer.appNo || '—'}</div>
          </div>
          <div className="flex p-3 bg-slate-50">
            <div className="w-56 font-bold text-slate-700">9. Aadhaar Number:</div>
            <div className="flex-1 font-mono">{maskAadhaar(customer.aadhar) || '—'}</div>
          </div>
          <div className="flex p-3">
            <div className="w-56 font-bold text-slate-700">10. Work Completion Date:</div>
            <div className="flex-1">
              <input
                type="date"
                value={wcc.completionDate}
                onChange={(e) => onWccChange({ ...wcc, completionDate: e.target.value })}
                className="border-b border-dashed border-current bg-transparent font-bold focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Declaration Notice */}
        <div className="mt-6 rounded-lg border border-slate-300 bg-slate-50 p-4 text-[11px] leading-relaxed text-slate-700">
          <p>
            <b>Customer Undertaking:</b> I hereby confirm that the solar plant has been installed at my premises in full working condition with all necessary safety equipment including Earth Electrode, ACDB, DCDB, and Lightning Arrester. The system is ready for net-metering synchronization with DISCOM.
          </p>
        </div>

        {/* Dual Signature */}
        <div className="mt-14 flex items-end justify-between text-xs">
          <div className="text-center">
            <div className="w-48 border-t-2 border-slate-800 mb-1" />
            <div className="font-bold text-slate-800">Signature of Site Owner</div>
            <div className="text-[10px] text-slate-500">Name: {customer.name || 'Consumer'}</div>
          </div>

          <div className="text-center flex flex-col items-center">
            <div className="text-xs font-bold text-slate-900">For {firm.name}</div>
            {firm.signature ? (
              <div className="h-12 flex items-center justify-center my-1">
                <img
                  src={firm.signature}
                  alt="Authorised Signatory"
                  className="max-h-12 max-w-[160px] object-contain"
                />
              </div>
            ) : (
              <div className="h-10" />
            )}
            <div className="w-48 border-t-2 border-slate-800 mb-1" />
            <div className="font-bold text-slate-800">Authorised Signatory</div>
            <div className="text-[10px] text-slate-500">With Stamp & Date</div>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // Render: Solar Quotation (Lump sum) or Commercial Quotation
  // -------------------------------------------------------------
  if (docType === 'quotation') {
    const isSolar = trade === 'solar';

    return (
      <div className="mx-auto w-full max-w-4xl bg-white text-slate-900 p-8 shadow-2xl rounded-xl print:shadow-none print:p-0">
        {/* Header */}
        <div className="rounded-xl bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 p-6 text-white shadow-md">
          {renderFirmHeader(2)}
        </div>

        {renderMetaRow('bg-emerald-50 text-emerald-950', 'text-emerald-950')}
        {renderCustomerBoxes('border-emerald-200 bg-emerald-50/30', 'text-emerald-800')}

        {/* Quotation Solar ROI Banner - Only for Solar trade */}
        {isSolar && (
          <div className="mt-4 rounded-xl border border-emerald-300 bg-emerald-50 p-4">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-emerald-900 mb-2 flex items-center gap-1.5">
              <Sun className="h-4 w-4 text-emerald-700" /> PM Surya Ghar Expected Benefits & Subsidy
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="rounded-lg bg-white p-2.5 border border-emerald-200">
                <div className="text-[10px] text-slate-500">Plant Capacity</div>
                <div className="text-sm font-bold text-emerald-800">{quotation.plantCapacityKw || '3 kW'}</div>
              </div>
              <div className="rounded-lg bg-white p-2.5 border border-emerald-200">
                <div className="text-[10px] text-slate-500">Annual Generation</div>
                <div className="text-sm font-bold text-emerald-800">
                  ~{quotation.annualGenerationUnits || '4,300'} Units/Yr
                </div>
              </div>
              <div className="rounded-lg bg-white p-2.5 border border-emerald-200">
                <div className="text-[10px] text-slate-500">Annual Bill Savings</div>
                <div className="text-sm font-bold text-emerald-800">
                  ~{currency} {formatIntegerINR(quotation.annualSavingsRs || 34400)}
                </div>
              </div>
              <div className="rounded-lg bg-white p-2.5 border border-emerald-200">
                <div className="text-[10px] text-slate-500">Direct Central Subsidy</div>
                <div className="text-sm font-extrabold text-amber-600">
                  {currency} {formatIntegerINR(quotation.subsidyAmount || 78000)}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Scope of Supply Table for Solar vs Standard Itemized Table for other trades */}
        {isSolar ? (
          <div className="mt-4 overflow-x-auto">
            <div className="mb-2 flex items-center justify-between">
              <h4 className="text-xs font-black uppercase tracking-wider text-emerald-950 flex items-center gap-1.5">
                <span>📦</span> Scope of Supply & System Specifications (Turnkey Package)
              </h4>
              <span className="text-[10px] text-slate-500 font-medium">Turnkey All-Inclusive Supply & Commissioning</span>
            </div>
            <table className="w-full border-collapse text-left text-xs">
              <thead>
                <tr className="bg-emerald-800 text-white font-bold">
                  <th className="py-2 px-2 text-center w-8">#</th>
                  <th className="py-2 px-3">Component Description & Engineering Specifications</th>
                  <th className="py-2 px-2 text-center w-16">Qty</th>
                  <th className="py-2 px-2 text-center w-16">Unit</th>
                  <th className="py-2 px-3 text-right">Standard Warranty / Scope</th>
                  <th className="py-2 px-1 text-center w-8 print:hidden"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {items.map((it, idx) => (
                  <tr key={it.id} className="hover:bg-emerald-50/40">
                    <td className="py-2 px-2 text-center font-bold text-slate-500">{idx + 1}</td>
                    <td className="py-2 px-3">
                      <input
                        type="text"
                        value={it.name}
                        onChange={(e) => handleItemChange(it.id, 'name', e.target.value)}
                        placeholder="Item description & specification"
                        className="w-full bg-transparent font-semibold text-slate-900 focus:outline-none"
                      />
                      {it.serialNumbers && (
                        <div className="text-[10px] text-slate-500 font-medium">{it.serialNumbers}</div>
                      )}
                    </td>
                    <td className="py-2 px-2 text-center">
                      <input
                        type="number"
                        value={it.qty || ''}
                        onChange={(e) => handleItemChange(it.id, 'qty', Number(e.target.value))}
                        className="w-full text-center bg-transparent font-bold focus:outline-none"
                      />
                    </td>
                    <td className="py-2 px-2 text-center font-medium text-slate-600">{it.unit || 'NOS'}</td>
                    <td className="py-2 px-3 text-right font-medium text-emerald-800 text-[11px]">
                      {it.name.toLowerCase().includes('module') || it.name.toLowerCase().includes('panel')
                        ? '25 Yrs Performance (ALMM DCR)'
                        : it.name.toLowerCase().includes('inverter')
                        ? '5-10 Yrs Manufacturer Warranty'
                        : it.name.toLowerCase().includes('structure')
                        ? 'HDG 80 Micron (10 Yrs Warranty)'
                        : it.name.toLowerCase().includes('cable') || it.name.toLowerCase().includes('wire')
                        ? 'Complete Wiring & Connection Scope'
                        : 'Installer Workmanship & Scope'}
                    </td>
                    <td className="py-2 px-1 text-center print:hidden">
                      <button
                        onClick={() => handleDeleteItemRow(it.id)}
                        className="text-slate-400 hover:text-rose-500 p-0.5"
                        title="Delete row"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Lump-Sum Turnkey Package Price Summary */}
            <div className="mt-3 rounded-xl border border-emerald-300 bg-emerald-50/50 p-4">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1 text-xs">
                  <div className="font-bold text-slate-800 uppercase tracking-wide">
                    Turnkey Commercial Offer ({quotation.plantCapacityKw || '3 kW'} On-Grid Rooftop)
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    Price includes design, supply of ALMM solar modules, grid-tied inverter, structure, ACDB/DCDB, lightning arrester, chemical earthing, testing, DISCOM net-metering liaisoning & 5-year comprehensive maintenance.
                  </p>
                </div>
                <div className="shrink-0 rounded-lg bg-emerald-900 text-white p-3 text-right min-w-[260px] shadow-sm">
                  <div className="text-[10px] text-emerald-200 uppercase font-bold tracking-wider">
                    Lump Sum Turnkey Deal Amount
                  </div>
                  <div className="text-xl font-black text-white mt-0.5">
                    {currency} {formatIntegerINR(grandTotal)}
                  </div>
                  <div className="text-[10px] text-emerald-300 mt-1">
                    (All-inclusive of Turnkey Supply, Installation & GST)
                  </div>
                  {quotation.subsidyAmount > 0 && (
                    <div className="mt-2 pt-2 border-t border-emerald-700/80 text-[11px]">
                      <div className="flex justify-between text-amber-300 font-semibold">
                        <span>Less Govt Subsidy:</span>
                        <span>- {currency} {formatIntegerINR(quotation.subsidyAmount)}</span>
                      </div>
                      <div className="flex justify-between font-black text-white mt-0.5 text-xs">
                        <span>Net Site Owner Cost:</span>
                        <span>{currency} {formatIntegerINR(Math.max(0, grandTotal - quotation.subsidyAmount))}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Add Row Button in Table */}
            <div className="mt-2 flex justify-start print:hidden">
              <button
                onClick={handleAddItemRow}
                className="flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 shadow-sm"
              >
                <Plus className="h-3.5 w-3.5 text-emerald-600" /> + Add Specification Row
              </button>
            </div>
          </div>
        ) : (
          renderItemsTable(
            'bg-emerald-800 text-white font-bold',
            'bg-emerald-100 text-emerald-950 font-extrabold border-t-2 border-emerald-600'
          )
        )}

        {renderGstBreakdown('bg-emerald-800 text-white font-bold')}
        {renderFooter('bg-emerald-50 text-emerald-950', 'border-emerald-800')}
      </div>
    );
  }

  // -------------------------------------------------------------
  // Render: MARGIN MONEY & BENEFICIARY PAYMENT RECEIPT
  // -------------------------------------------------------------
  if (docType === 'receipt') {
    const totalDeal = marginReceipt?.totalProjectDealAmount || grandTotal || 180000;
    const expectedSubsidy = marginReceipt?.expectedSubsidyAmount || quotation.subsidyAmount || 78000;
    const marginDue = Math.max(0, totalDeal - expectedSubsidy);
    const amountRcvd = marginReceipt?.amountReceived !== undefined ? marginReceipt.amountReceived : 50000;
    const balRemaining = Math.max(0, marginDue - amountRcvd);
    const mode = marginReceipt?.paymentMode || 'CASH';

    const handleReceiptFieldChange = (field: keyof MarginReceiptDetails, val: any) => {
      if (!onMarginReceiptChange) return;
      const updated: MarginReceiptDetails = {
        receiptNo: marginReceipt?.receiptNo || 'REC/26-27/001',
        receiptDate: marginReceipt?.receiptDate || new Date().toISOString().split('T')[0],
        customerName: customer.name,
        customerMobile: customer.mobile,
        customerAddress: customer.address,
        consumerNo: customer.consumerNo,
        appNo: customer.appNo,
        totalProjectDealAmount: totalDeal,
        expectedSubsidyAmount: expectedSubsidy,
        marginMoneyDue: marginDue,
        amountReceived: amountRcvd,
        amountReceivedWords: numberToWordsRupees(amountRcvd),
        balanceRemaining: balRemaining,
        paymentMode: mode,
        transactionRef: marginReceipt?.transactionRef || 'CASH-SLIP-01',
        notes: marginReceipt?.notes || '',
        ...marginReceipt,
        [field]: val,
      };
      if (field === 'totalProjectDealAmount' || field === 'expectedSubsidyAmount' || field === 'amountReceived') {
        const d = field === 'totalProjectDealAmount' ? Number(val) : updated.totalProjectDealAmount;
        const s = field === 'expectedSubsidyAmount' ? Number(val) : updated.expectedSubsidyAmount;
        const r = field === 'amountReceived' ? Number(val) : updated.amountReceived;
        const m = Math.max(0, d - s);
        updated.marginMoneyDue = m;
        updated.amountReceived = r;
        updated.balanceRemaining = Math.max(0, m - r);
        updated.amountReceivedWords = numberToWordsRupees(r);
      }
      onMarginReceiptChange(updated);
    };

    return (
      <div className="relative mx-auto w-full max-w-4xl bg-white text-slate-900 p-6 sm:p-8 shadow-2xl rounded-xl print:shadow-none print:p-0 overflow-hidden">
        {renderWatermark()}
        {/* Firm Header */}
        <div className="border-b-4 border-amber-600 pb-4 relative z-10">
          {renderFirmHeader(1)}
        </div>

        {/* Receipt Header Badge & Serial Info */}
        <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-amber-200 bg-amber-50/70 p-3 rounded-xl relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-lg bg-amber-600 text-white font-black text-xs px-2.5 py-1 uppercase tracking-wider">
                PAYMENT SLIP
              </span>
              <h2 className="text-sm sm:text-base font-black text-amber-950">
                {lang === 'hi' ? 'मार्जिन मनी व नकद भुगतान रसीद' : 'MARGIN MONEY & PAYMENT RECEIPT'}
              </h2>
            </div>
            <p className="text-[10px] text-amber-800 mt-0.5">
              PM Surya Ghar: Muft Bijli Yojana & Rooftop Solar Customer Contribution
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-bold text-slate-800">
            <div>
              <span className="text-[10px] text-slate-500 uppercase block">Receipt No</span>
              <input
                type="text"
                value={marginReceipt?.receiptNo || 'REC/26-27/001'}
                onChange={(e) => handleReceiptFieldChange('receiptNo', e.target.value)}
                className="font-mono font-black text-amber-700 bg-transparent border-b border-dashed border-slate-400 focus:outline-none w-32"
              />
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase block">Date</span>
              <input
                type="date"
                value={marginReceipt?.receiptDate || new Date().toISOString().split('T')[0]}
                onChange={(e) => handleReceiptFieldChange('receiptDate', e.target.value)}
                className="font-bold text-slate-900 bg-transparent border-b border-dashed border-slate-400 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Beneficiary / Customer Details */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 relative z-10 text-xs">
          <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 space-y-1">
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
              <span>👤</span> Received with thanks from (Beneficiary):
            </div>
            <div className="font-extrabold text-sm text-slate-900">{customer.name || 'Valued Solar Beneficiary'}</div>
            {customer.relation && <div className="text-[11px] text-slate-600">{customer.relation}</div>}
            <div className="text-[11px] text-slate-600 whitespace-pre-line">{customer.address || 'Installation Site Address'}</div>
            {customer.mobile && (
              <div className="text-[11px] text-slate-700">
                <b>Mobile:</b> {customer.mobile}
              </div>
            )}
            {customer.aadhar && (
              <div className="text-[11px] text-slate-700">
                <b>Aadhaar:</b> {maskAadhaar(customer.aadhar)}
              </div>
            )}
          </div>

          <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 space-y-1.5">
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
              <span>☀️</span> Solar Installation Site Reference:
            </div>
            <div className="text-[11px] text-slate-700 flex justify-between">
              <span className="text-slate-500">DISCOM Consumer / K-No:</span>
              <span className="font-bold text-slate-900">{customer.consumerNo || '—'}</span>
            </div>
            <div className="text-[11px] text-slate-700 flex justify-between">
              <span className="text-slate-500">PM Surya Ghar App No:</span>
              <span className="font-mono font-bold text-amber-700">{customer.appNo || '—'}</span>
            </div>
            <div className="text-[11px] text-slate-700 flex justify-between">
              <span className="text-slate-500">Sanctioned Plant Capacity:</span>
              <span className="font-bold text-emerald-800">{customer.sanctionLoad || wcc.plantCapacityKw || '3.00 kW'}</span>
            </div>
            <div className="text-[11px] text-slate-700 flex justify-between">
              <span className="text-slate-500">Grid Connected DISCOM:</span>
              <span className="font-medium text-slate-800">{wcc.discomName || 'State DISCOM'}</span>
            </div>
          </div>
        </div>

        {/* Payment Account Breakdown Table */}
        <div className="mt-5 rounded-2xl border border-amber-300 bg-amber-50/30 overflow-hidden relative z-10 shadow-sm">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-amber-600 text-white font-bold">
                <th className="py-2.5 px-3">Description / Financial Head</th>
                <th className="py-2.5 px-3 text-right w-44">Amount ({currency})</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-amber-200/70 text-slate-800">
              <tr>
                <td className="py-2.5 px-3">
                  <div className="font-bold text-slate-900">Total Turnkey Solar EPC Project Deal Cost</div>
                  <div className="text-[10px] text-slate-500">Includes modules, inverter, structure, wiring & turnkey commissioning</div>
                </td>
                <td className="py-2.5 px-3 text-right font-bold text-slate-900 text-sm">
                  {currency} {formatIntegerINR(totalDeal)}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 px-3">
                  <div className="font-bold text-emerald-800">Less: Expected Central Govt Direct DBT Subsidy</div>
                  <div className="text-[10px] text-emerald-700">Credited directly to beneficiary Aadhaar-linked bank account</div>
                </td>
                <td className="py-2.5 px-3 text-right font-extrabold text-emerald-700 text-sm">
                  - {currency} {formatIntegerINR(expectedSubsidy)}
                </td>
              </tr>
              <tr className="bg-amber-100/60 font-bold">
                <td className="py-2.5 px-3 text-amber-950 font-black">
                  Total Customer Contribution (Net Margin Money Payable)
                </td>
                <td className="py-2.5 px-3 text-right font-black text-amber-950 text-sm">
                  {currency} {formatIntegerINR(marginDue)}
                </td>
              </tr>
              <tr className="bg-emerald-500/10 font-bold">
                <td className="py-3 px-3">
                  <div className="text-emerald-950 font-black text-sm flex items-center gap-1.5">
                    <span>💵</span> Amount Received in This Receipt
                  </div>
                  <div className="text-[10px] text-emerald-800 font-semibold mt-0.5">
                    Mode: {mode} {marginReceipt?.transactionRef ? `| Ref: ${marginReceipt.transactionRef}` : ''}
                  </div>
                </td>
                <td className="py-3 px-3 text-right font-black text-emerald-800 text-base">
                  <div className="print:hidden">
                    <input
                      type="number"
                      value={amountRcvd}
                      onChange={(e) => handleReceiptFieldChange('amountReceived', Number(e.target.value))}
                      className="w-32 text-right bg-white border border-emerald-400 rounded px-2 py-1 font-black text-emerald-800 focus:outline-none"
                    />
                  </div>
                  <span className="hidden print:inline">
                    {currency} {formatIntegerINR(amountRcvd)}
                  </span>
                </td>
              </tr>
              <tr className="bg-slate-100/80">
                <td className="py-2.5 px-3 text-slate-700 font-bold">
                  Remaining Balance Margin Money Due Post This Receipt
                </td>
                <td className="py-2.5 px-3 text-right font-black text-rose-700 text-sm">
                  {currency} {formatIntegerINR(balRemaining)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Amount in words callout */}
        <div className="mt-3 rounded-xl border border-emerald-200 bg-emerald-50 p-3 relative z-10">
          <div className="text-[10px] uppercase font-bold text-emerald-900">
            Amount Received (in words):
          </div>
          <div className="font-extrabold text-xs text-emerald-950 capitalize mt-0.5">
            {numberToWordsRupees(amountRcvd)} Only
          </div>
        </div>

        {/* Payment Mode Selector & Transaction Ref in Editor */}
        <div className="mt-3 flex flex-wrap items-center gap-3 print:hidden bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs">
          <span className="font-bold text-slate-700">Payment Mode:</span>
          {(['CASH', 'UPI', 'NEFT_RTGS', 'CHEQUE'] as const).map((m) => (
            <label key={m} className="flex items-center gap-1.5 cursor-pointer font-semibold text-slate-800">
              <input
                type="radio"
                name="receiptMode"
                value={m}
                checked={mode === m}
                onChange={() => handleReceiptFieldChange('paymentMode', m)}
                className="text-amber-600 focus:ring-amber-500"
              />
              <span>{m === 'CASH' ? '💵 Cash' : m === 'UPI' ? '📱 UPI' : m === 'NEFT_RTGS' ? '🏛️ NEFT/Bank' : '📄 Cheque'}</span>
            </label>
          ))}
          <div className="ml-auto flex items-center gap-2">
            <span className="text-[11px] text-slate-500">Ref / Slip No:</span>
            <input
              type="text"
              value={marginReceipt?.transactionRef || ''}
              placeholder="e.g. UPI-1234 / Cash Slip #1"
              onChange={(e) => handleReceiptFieldChange('transactionRef', e.target.value)}
              className="rounded border border-slate-300 px-2 py-0.5 text-xs text-slate-900 bg-white focus:outline-none"
            />
          </div>
        </div>

        {/* Official Statutory Declaration & Signatures */}
        <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50/40 p-3 text-[10px] text-slate-600 leading-relaxed relative z-10">
          <b>DECLARATION:</b> Received the above payment towards Customer Margin Money contribution for installation and commissioning of Grid-Interactive Solar Rooftop Photovoltaic Power Plant under PM Surya Ghar Muft Bijli Yojana. Subject to realisation of cheque / electronic transfer. Government subsidy DBT is subject to DISCOM inspection and portal processing.
        </div>

        {/* Dual Signatures */}
        <div className="mt-8 grid grid-cols-2 gap-8 text-center relative z-10 text-xs">
          <div className="border-t-2 border-slate-400 pt-2 text-slate-600">
            <div className="font-bold text-slate-800">{customer.name || 'Beneficiary'}</div>
            <div className="text-[10px] text-slate-500">Customer / Beneficiary Signature (ग्राहक हस्ताक्षर)</div>
          </div>
          <div className="border-t-2 border-slate-900 pt-2">
            {firm.signature && (
              <img src={firm.signature} alt="Sign" className="h-10 mx-auto object-contain mb-1" />
            )}
            <div className="font-extrabold text-slate-900">{firm.name}</div>
            <div className="text-[10px] font-bold text-slate-500">Authorized Signatory & Receiver Stamp</div>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // Render: Bank Loan Margin Money Estimate
  // -------------------------------------------------------------
  if (docType === 'estimate') {
    if (trade !== 'solar') {
      return (
        <div className="mx-auto w-full max-w-2xl bg-white text-slate-900 p-8 shadow-xl rounded-xl text-center">
          <div className="rounded-xl border border-indigo-300 bg-indigo-50 p-6">
            <h3 className="text-base font-bold text-indigo-900">
              Document Not Applicable for {trade.replace('_', ' ').toUpperCase()}
            </h3>
            <p className="mt-2 text-xs text-indigo-700">
              Bank Loan Margin Money Estimate is specific to PM Surya Ghar & Solar Rooftop bank financing.
              Please switch to <b>Tax Invoice</b> or <b>Quotation</b> for your active trade.
            </p>
          </div>
        </div>
      );
    }

    return (
      <div className="mx-auto w-full max-w-4xl bg-white text-slate-900 p-8 shadow-2xl rounded-xl print:shadow-none print:p-0">
        <div className="rounded-xl border-t-4 border-indigo-700 bg-slate-50 p-5 shadow-sm">
          {renderFirmHeader(1)}
        </div>

        {renderMetaRow('bg-indigo-50 text-indigo-950', 'text-indigo-950')}
        {renderCustomerBoxes('border-indigo-200 bg-indigo-50/20', 'text-indigo-800')}

        <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-2.5 text-[11px] text-amber-900 leading-relaxed font-medium text-center">
          <b>NOTE FOR BANK (SBI / PNB / BOB Solar Loan):</b> This is an official proforma cost estimate for the purpose of solar rooftop bank loan appraisal and margin money determination. Subsidy of up to ₹78,000 will be credited directly to consumer's bank account under PM Surya Ghar Yojana.
        </div>

        {renderItemsTable(
          'bg-indigo-900 text-white font-bold',
          'bg-indigo-100 text-indigo-950 font-extrabold border-t-2 border-indigo-700'
        )}

        {renderGstBreakdown('bg-indigo-900 text-white font-bold')}
        {renderFooter('bg-indigo-50 text-indigo-950', 'border-indigo-900')}
      </div>
    );
  }

  // -------------------------------------------------------------
  // Render: TAX INVOICE (3 Professional Themes)
  // -------------------------------------------------------------
  if (templateStyle === 2) {
    // Theme 2: Corporate Blue
    return (
      <div className="relative mx-auto w-full max-w-4xl bg-white text-slate-900 shadow-2xl rounded-xl overflow-hidden print:shadow-none print:rounded-none">
        {renderWatermark()}
        <div
          className="p-6 text-white"
          style={accentColor ? { backgroundColor: accentColor } : { background: 'linear-gradient(to right, #172554, #1e3a8a, #312e81)' }}
        >
          {renderFirmHeader(2)}
        </div>
        <div className="h-1.5 bg-amber-400" />
        <div className="relative z-10 p-6">
          {renderMetaRow('bg-blue-50 text-blue-950', 'text-blue-950')}
          {renderCustomerBoxes('border-blue-200 bg-blue-50/30', 'text-blue-800')}
          {renderItemsTable(
            'bg-blue-900 text-white font-bold',
            'bg-blue-100 text-blue-950 font-extrabold border-t-2 border-blue-600'
          )}
          {renderGstBreakdown('bg-blue-900 text-white font-bold')}
          {renderFooter('bg-blue-50 text-blue-950', 'border-blue-900')}
        </div>
      </div>
    );
  }

  if (templateStyle === 3) {
    // Theme 3: Midnight Dark & Gold (Solar Tech)
    return (
      <div className="relative mx-auto w-full max-w-4xl bg-slate-900 text-slate-100 shadow-2xl rounded-xl overflow-hidden print:bg-white print:text-slate-900 print:shadow-none">
        {renderWatermark()}
        <div className="bg-slate-950 p-6 border-b-2 border-amber-400">
          {renderFirmHeader(3)}
        </div>
        <div className="relative z-10 p-6">
          {renderMetaRow('bg-slate-950 text-slate-200', 'text-slate-200')}
          {renderCustomerBoxes('border-slate-800 bg-slate-950/50', 'text-amber-400')}
          {renderItemsTable(
            'bg-slate-950 text-amber-400 font-bold',
            'bg-amber-400 text-slate-950 font-extrabold border-t-2 border-amber-500'
          )}
          {renderGstBreakdown('bg-slate-950 text-amber-400 font-bold')}
          {renderFooter('bg-slate-950 text-slate-300', 'border-amber-400')}
        </div>
      </div>
    );
  }

  // Theme 1: Clean Minimal White
  return (
    <div className="relative mx-auto w-full max-w-4xl bg-white text-slate-900 p-6 sm:p-8 shadow-2xl rounded-xl print:shadow-none print:p-0 overflow-hidden">
      {renderWatermark()}
      <div
        className="border-b-4 border-slate-900 pb-4 relative z-10"
        style={accentColor ? { borderBottomColor: accentColor } : undefined}
      >
        {renderFirmHeader(1)}
      </div>
      <div className="relative z-10">
        {renderMetaRow('bg-slate-100 text-slate-800', 'text-slate-800')}
        {renderCustomerBoxes('border-slate-300 bg-slate-50/50', 'text-slate-900')}
        {renderItemsTable(
          'bg-slate-900 text-white font-bold',
          'bg-slate-900 text-amber-400 font-extrabold border-t-2 border-slate-800'
        )}
        {renderGstBreakdown('bg-slate-900 text-white font-bold')}
        {renderFooter('bg-slate-100 text-slate-800', 'border-slate-900')}
      </div>
    </div>
  );
};
