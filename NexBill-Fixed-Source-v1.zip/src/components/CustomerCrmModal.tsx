import React, { useState } from 'react';
import { CustomerInfo, InvoiceHistoryRecord, InvoiceItem } from '../types/solar';
import { formatINR, formatIntegerINR } from '../services/licenseService';
import { Users, History, Search, Plus, Trash2, ArrowUpRight, Share2, Download, X, Check } from 'lucide-react';

interface CustomerCrmModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerList: CustomerInfo[];
  onSaveCustomerList: (list: CustomerInfo[]) => void;
  onSelectCustomer: (cust: CustomerInfo) => void;
  invoicesHistory: InvoiceHistoryRecord[];
  onLoadInvoiceRecord: (record: InvoiceHistoryRecord) => void;
  onDeleteHistoryRecord: (id: string) => void;
}

export const CustomerCrmModal: React.FC<CustomerCrmModalProps> = ({
  isOpen,
  onClose,
  customerList,
  onSaveCustomerList,
  onSelectCustomer,
  invoicesHistory,
  onLoadInvoiceRecord,
  onDeleteHistoryRecord,
}) => {
  const [activeTab, setActiveTab] = useState<'crm' | 'history'>('crm');
  const [searchTerm, setSearchTerm] = useState('');

  // Add new customer modal form
  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newRelation, setNewRelation] = useState('');
  const [newAddress, setNewAddress] = useState('');
  const [newMobile, setNewMobile] = useState('');
  const [newAadhar, setNewAadhar] = useState('');
  const [newAppNo, setNewAppNo] = useState('');
  const [newConsumerNo, setNewConsumerNo] = useState('');
  const [newSanctionLoad, setNewSanctionLoad] = useState('3.00 kW');
  const [newGstin, setNewGstin] = useState('');

  if (!isOpen) return null;

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) {
      alert('Please enter customer name');
      return;
    }
    const newCust: CustomerInfo = {
      name: newName.trim(),
      relation: newRelation.trim(),
      address: newAddress.trim(),
      mobile: newMobile.trim(),
      aadhar: newAadhar.trim(),
      appNo: newAppNo.trim(),
      consumerNo: newConsumerNo.trim(),
      sanctionLoad: newSanctionLoad.trim(),
      gstin: newGstin.trim().toUpperCase(),
    };

    const updated = [newCust, ...customerList.filter((c) => c.name !== newCust.name)];
    onSaveCustomerList(updated);
    setShowAddForm(false);
    // Reset
    setNewName('');
    setNewRelation('');
    setNewAddress('');
    setNewMobile('');
    setNewAadhar('');
    setNewAppNo('');
    setNewConsumerNo('');
    setNewGstin('');
  };

  const handleDeleteCustomer = (name: string) => {
    if (confirm(`Delete customer "${name}" from CRM directory?`)) {
      onSaveCustomerList(customerList.filter((c) => c.name !== name));
    }
  };

  const handleWhatsAppChat = (cust: CustomerInfo) => {
    const text = encodeURIComponent(`Hello ${cust.name}, greetings from Jagga Enterprises & Co. Solar Power Solutions.`);
    const phone = cust.mobile ? cust.mobile.replace(/[^0-9]/g, '') : '';
    window.open(`https://wa.me/91${phone}?text=${text}`, '_blank');
  };

  const handleExportCustomersCSV = () => {
    const headers = [
      'Name',
      'Relation',
      'Address',
      'Mobile',
      'Aadhaar',
      'Surya Ghar App No',
      'Consumer K-No',
      'Sanctioned Load',
      'GSTIN',
    ];
    const rows = customerList.map((c) => [
      `"${c.name}"`,
      `"${c.relation}"`,
      `"${(c.address || '').replace(/\n/g, ' ')}"`,
      `"${c.mobile}"`,
      `"${c.aadhar}"`,
      `"${c.appNo}"`,
      `"${c.consumerNo}"`,
      `"${c.sanctionLoad}"`,
      `"${c.gstin}"`,
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Solar_Customers_CRM_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-6 backdrop-blur-md">
      <div className="flex h-[92vh] w-full max-w-5xl flex-col rounded-3xl border border-purple-500/40 bg-slate-900 shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-purple-500/20 text-purple-400">
              <Users className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                Customer Database CRM & History
                <span className="rounded-full bg-purple-500/20 px-2.5 py-0.5 text-[10px] font-bold text-purple-300 border border-purple-500/30">
                  Business Plan
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Manage solar rooftop clients, repeat orders, and past generated invoices.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 bg-slate-950/60 px-6 py-3">
          <div className="flex rounded-xl border border-slate-800 bg-slate-900 p-1 text-xs">
            <button
              onClick={() => setActiveTab('crm')}
              className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 font-bold transition ${
                activeTab === 'crm' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="h-3.5 w-3.5" />
              Customer Directory ({customerList.length})
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 font-bold transition ${
                activeTab === 'history' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <History className="h-3.5 w-3.5" />
              Invoice History ({invoicesHistory.length})
            </button>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Search by customer, phone, app no..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-purple-400 focus:outline-none w-64"
            />
            {activeTab === 'crm' && (
              <>
                <button
                  onClick={handleExportCustomersCSV}
                  className="flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-800"
                  title="Export to CSV"
                >
                  <Download className="h-3.5 w-3.5" /> CSV
                </button>
                <button
                  onClick={() => setShowAddForm(true)}
                  className="flex items-center gap-1.5 rounded-lg bg-purple-600 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-purple-500 shadow-md"
                >
                  <Plus className="h-3.5 w-3.5" /> + New Customer
                </button>
              </>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="flex flex-1 flex-col overflow-y-auto p-6">
          {/* Add New Customer Form Popup */}
          {showAddForm && (
            <form onSubmit={handleCreateCustomer} className="mb-4 rounded-2xl border border-purple-500/40 bg-slate-950 p-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3">
                <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Plus className="h-4 w-4" /> Add New Customer to CRM
                </h4>
                <button type="button" onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-white">
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Customer / Site Owner Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ramesh Chandra Sharma"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-white focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">S/O or W/O</label>
                  <input
                    type="text"
                    placeholder="S/O Mohan Lal Sharma"
                    value={newRelation}
                    onChange={(e) => setNewRelation(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-white focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Mobile Phone</label>
                  <input
                    type="text"
                    placeholder="98290-XXXXX"
                    value={newMobile}
                    onChange={(e) => setNewMobile(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-white focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Aadhaar No.</label>
                  <input
                    type="text"
                    placeholder="XXXX-XXXX-1234"
                    value={newAadhar}
                    onChange={(e) => setNewAadhar(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-white focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">PM Surya Ghar App No.</label>
                  <input
                    type="text"
                    placeholder="RJ-SG-2026-789104"
                    value={newAppNo}
                    onChange={(e) => setNewAppNo(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-amber-300 font-mono focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Consumer K-No.</label>
                  <input
                    type="text"
                    placeholder="1402/2390/4910"
                    value={newConsumerNo}
                    onChange={(e) => setNewConsumerNo(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-white focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Sanctioned Load</label>
                  <input
                    type="text"
                    placeholder="3.00 kW"
                    value={newSanctionLoad}
                    onChange={(e) => setNewSanctionLoad(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-white focus:border-purple-400 focus:outline-none"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-[11px] text-slate-400 block mb-1">Site Address</label>
                  <input
                    type="text"
                    placeholder="Ward No, Area, City, Pin Code"
                    value={newAddress}
                    onChange={(e) => setNewAddress(e.target.value)}
                    className="w-full rounded border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-white focus:border-purple-400 focus:outline-none"
                  />
                </div>
              </div>

              <div className="mt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="rounded border border-slate-700 px-3 py-1 text-xs text-slate-400 hover:bg-slate-800"
                >
                  Cancel
                </button>
                <button type="submit" className="rounded bg-purple-600 px-4 py-1 text-xs font-bold text-white hover:bg-purple-500">
                  Save Customer
                </button>
              </div>
            </form>
          )}

          {/* TAB 1: CRM TABLE */}
          {activeTab === 'crm' && (
            <div className="flex-1 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900 text-slate-400">
                    <th className="py-2.5 px-3">Site Owner / Name</th>
                    <th className="py-2.5 px-3">Mobile Phone</th>
                    <th className="py-2.5 px-3">Surya Ghar App No</th>
                    <th className="py-2.5 px-2">K-Number</th>
                    <th className="py-2.5 px-2">Load</th>
                    <th className="py-2.5 px-3">Address</th>
                    <th className="py-2.5 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {customerList
                    .filter((c) => {
                      if (!searchTerm) return true;
                      const s = searchTerm.toLowerCase();
                      return (
                        c.name.toLowerCase().includes(s) ||
                        (c.mobile && c.mobile.includes(s)) ||
                        (c.appNo && c.appNo.toLowerCase().includes(s)) ||
                        (c.consumerNo && c.consumerNo.includes(s))
                      );
                    })
                    .map((c, idx) => (
                      <tr key={idx} className="hover:bg-slate-900/50">
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-white">{c.name}</div>
                          {c.relation && <div className="text-[10px] text-slate-400">{c.relation}</div>}
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="font-medium text-slate-300">{c.mobile || '—'}</div>
                          {c.mobile && (
                            <button
                              onClick={() => handleWhatsAppChat(c)}
                              className="text-[10px] text-emerald-400 hover:underline flex items-center gap-1 mt-0.5"
                            >
                              <Share2 className="h-2.5 w-2.5" /> WhatsApp
                            </button>
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-mono font-bold text-amber-300">{c.appNo || '—'}</td>
                        <td className="py-2.5 px-2 font-mono text-slate-300">{c.consumerNo || '—'}</td>
                        <td className="py-2.5 px-2 font-bold text-emerald-400">{c.sanctionLoad || '—'}</td>
                        <td className="py-2.5 px-3 text-[11px] text-slate-400 max-w-xs truncate" title={c.address}>
                          {c.address || '—'}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => {
                                onSelectCustomer(c);
                                onClose();
                              }}
                              className="rounded bg-purple-600/30 border border-purple-500/50 px-2.5 py-1 text-[11px] font-bold text-purple-200 hover:bg-purple-600 hover:text-white transition flex items-center gap-1"
                              title="Load details into active invoice & WCC"
                            >
                              Load Bill <ArrowUpRight className="h-3 w-3" />
                            </button>
                            <button
                              onClick={() => handleDeleteCustomer(c.name)}
                              className="text-slate-500 hover:text-rose-400 p-1"
                              title="Delete from CRM"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>

              {customerList.length === 0 && (
                <div className="p-8 text-center text-slate-500">
                  No customers saved in CRM yet. Click "+ New Customer" to add your first solar client!
                </div>
              )}
            </div>
          )}

          {/* TAB 2: INVOICE HISTORY TABLE */}
          {activeTab === 'history' && (
            <div className="flex-1 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900 text-slate-400">
                    <th className="py-2.5 px-3">Doc No</th>
                    <th className="py-2.5 px-2">Date</th>
                    <th className="py-2.5 px-2">Type</th>
                    <th className="py-2.5 px-3">Customer Name</th>
                    <th className="py-2.5 px-2">Plant Capacity</th>
                    <th className="py-2.5 px-3 text-right">Grand Total (₹)</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {invoicesHistory
                    .filter((h) => {
                      if (!searchTerm) return true;
                      const s = searchTerm.toLowerCase();
                      return (
                        h.customerName.toLowerCase().includes(s) ||
                        h.invNo.toLowerCase().includes(s) ||
                        (h.customerMobile && h.customerMobile.includes(s))
                      );
                    })
                    .map((item) => (
                      <tr key={item.id} className="hover:bg-slate-900/50">
                        <td className="py-2.5 px-3 font-mono font-bold text-amber-300">{item.invNo}</td>
                        <td className="py-2.5 px-2 text-slate-300">{item.date}</td>
                        <td className="py-2.5 px-2">
                          <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] uppercase font-bold text-slate-300">
                            {item.docType}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="font-semibold text-white">{item.customerName}</div>
                          <div className="text-[10px] text-slate-400">{item.firmName}</div>
                        </td>
                        <td className="py-2.5 px-2 text-emerald-400 font-bold">{item.plantCapacityKw || '—'}</td>
                        <td className="py-2.5 px-3 text-right font-extrabold text-white">
                          ₹ {formatIntegerINR(item.grandTotal)}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                onLoadInvoiceRecord(item);
                                onClose();
                              }}
                              className="rounded bg-amber-500/20 border border-amber-500/40 px-2.5 py-1 text-[11px] font-bold text-amber-300 hover:bg-amber-500 hover:text-slate-950 transition"
                            >
                              Re-Open Bill
                            </button>
                            <button
                              onClick={() => onDeleteHistoryRecord(item.id)}
                              className="text-slate-500 hover:text-rose-400 p-1"
                              title="Delete record"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>

              {invoicesHistory.length === 0 && (
                <div className="p-8 text-center text-slate-500">
                  No invoices printed or saved to history yet. Whenever you print an invoice, it is automatically logged here!
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
